# -*- coding: utf-8 -*-
"""English equivalents for every generated (template) Bangla sentence. Keys are the exact Bangla text."""
EN = {
# ---- notes ----
"কালো তালিকাভুক্ত (Blacklist) ব্যক্তি যাচাই রেমিট্যান্স নিয়ন্ত্রণের অংশ। লেনদেন প্রক্রিয়ার আগে Agency-কে Remitter কালো তালিকায় আছে কিনা যাচাই করতে হয়।":
 "Blacklist checking is part of remittance control. Before processing a transaction, the Agency must check whether the Remitter is blacklisted.",
"উচ্চ-ঝুঁকির রেমিট্যান্সে AVR (Adeguata Verifica Rafforzata — বাড়তি যাচাই) তথ্য দিতে হয় এবং Export-এর আগে লেনদেনটি Review-এর জন্য Hold থাকতে পারে।":
 "Higher-risk remittances require AVR (Adeguata Verifica Rafforzata — enhanced verification) information, and the transaction may be held for review before export.",
"লেনদেনের Exchange Rate (মুদ্রা বিনিময় হার) অবশ্যই নির্ধারিত সর্বনিম্ন ও সর্বোচ্চ সীমার মধ্যে থাকতে হবে। অনুমোদিত রেট প্রকাশের পরেই Agency রেমিট্যান্স শুরু করে।":
 "The transaction Exchange Rate must stay within the configured minimum and maximum. Agencies start issuing remittances only after approved rates are published.",
"Remitter-এর লেনদেন সীমা দিন, মাস ও বছর অনুযায়ী যাচাই হয়; লেনদেন, Remitter ও Beneficiary-র সীমা Administrator নির্ধারণ করেন।":
 "Remitter transaction limits are checked by day, month and year; transaction, Remitter and Beneficiary limits are configured by the Administrator.",
"TT বাতিল (Cancellation) ও সংশোধন (Correction) সম্পন্ন করার আগে পর্যালোচনা ও অনুমোদন প্রয়োজন। অনুমোদনের পরেই Agency গ্রাহককে টাকা ফেরত (Refund) দেয়।":
 "TT Cancellation and Correction need review and approval before completion. The Agency refunds the customer only after approval.",
"কোনো TT-র কোম্পানি, ব্যাংক বা প্রসেসিং স্ট্যাটাস পরিবর্তনের আগে Central Admin-এর অনুমোদন প্রয়োজন।":
 "Central Admin authorisation is required before changing a TT's company, bank or processing status.",
"কোনো সমস্যা থাকলে রেমিট্যান্স Hold করা হয় এবং সমস্যা সমাধানের পর Release করা হয়। Agency Hold থাকা লেনদেন ও তার কারণ দেখতে পারে।":
 "A remittance is put on Hold when there is a problem and released once it is resolved. The Agency can see held transactions and their hold reasons.",
"Agent-এর লেনদেন শুধু অনুমোদিত (MAC/IP দ্বারা চিহ্নিত) কম্পিউটার থেকে করা যায়।":
 "Agent transactions can only be made from approved computers (identified by MAC/IP).",
"হিসাবের ভাউচার General Ledger-এ পোস্ট করার আগে যাচাই ও যথাযথ অনুমোদন প্রয়োজন।":
 "Accounting vouchers must be checked and properly approved before they are posted to the General Ledger.",
"Remitter ও Agent-এর ডকুমেন্টের মেয়াদ ও অবস্থা (missing, uploaded, expired) ট্র্যাক করা হয়।":
 "Validity and status of Remitter and Agent documents (missing, uploaded, expired) are tracked.",
"নতুন তৈরি বা পরিবর্তিত Remitter-এর তথ্য Review ও অনুমোদন করতে হয়।":
 "Newly created or changed Remitter information must be reviewed and approved.",
"প্রত্যেক ইউজার শুধু নিজের User Group-এ দেওয়া অনুমতি অনুযায়ী মেনু ও কাজ ব্যবহার করতে পারেন। লগইন প্রচেষ্টা, ডিভাইস, IP ও প্রবেশ প্রত্যাখ্যানের কারণ রেকর্ড রাখা হয়।":
 "Each user can use only the menus and actions allowed for their User Group. Login attempts, devices, IP addresses and denied-access reasons are recorded.",
"ডুপ্লিকেট Remitter/Beneficiary রেকর্ড সম্পাদনা, মুছে ফেলা বা একীকরণ (Merge) যথাযথ নিয়ন্ত্রণের অধীনে করতে হয়।":
 "Editing, deleting or merging duplicate Remitter/Beneficiary records must be done under proper control.",
"Coverfund হলো Payout পার্টনারকে লেনদেন পরিশোধের জন্য আগাম পাঠানো অর্থ। দৈনিক Coverfund পরিমাণ, রূপান্তর হার ও এক্সচেঞ্জ আয় হিসাব করা হয়।":
 "Coverfund is money sent in advance to a payout partner to cover payments. Daily coverfund amounts, conversion rates and exchange earnings are calculated.",
"দিনশেষে টেলার ও মুদ্রাভিত্তিক সারসংক্ষেপ তৈরি এবং Agent-এর দৈনিক অবস্থান (Position) হিসাব করা হয়।":
 "At end of day, teller and currency summaries are created and the Agent's daily position is calculated.",
"মাসিক আয় ভাগাভাগি (Income Sharing) প্রক্রিয়া করা হয় এবং অনুমোদিত সংশোধন প্রয়োজন হলে আবার চালানো যায়।":
 "Monthly Income Sharing is processed and can be re-run when approved corrections are needed.",
"চার্জ নির্দিষ্ট (Fixed) বা স্ল্যাব-ভিত্তিক হতে পারে; চার্জ, কমিশন ও আয় Exchange, Agent ও অন্যান্য পক্ষের মধ্যে নির্ধারিত নিয়মে ভাগ হয়।":
 "Charges can be fixed or slab-based; charges, commissions and income are shared between the Exchange, Agents and other parties by configured rules.",
"UIC (Unique Identification Code) রেফারেন্স ডেটা — অবস্থান, ব্যবসায়িক খাত, ঝুঁকির শ্রেণি, তৃতীয় পক্ষের সম্পর্ক ও গ্রহণযোগ্য ডকুমেন্টের ধরন — গ্রাহককে সঠিকভাবে শনাক্ত ও শ্রেণিবদ্ধ করতে ব্যবহৃত হয়।":
 "UIC (Unique Identification Code) reference data — locations, business sectors, risk classes, third-party relationships and accepted document types — is used to identify and classify customers correctly.",
"দেশভিত্তিক ছুটির তালিকা দৈনন্দিন কার্যক্রমে ব্যবহৃত হয়।": "Country-wise holidays are used by daily operations.",
"API ছাড়া ফাইলের মাধ্যমে যুক্ত পার্টনারের রেমিট্যান্স ফাইলের জন্য নিরাপত্তা কী (Testkey) ব্যবহৃত হয়।":
 "A security key (Testkey) is used for remittance files sent to partners connected by file instead of API.",
"পার্টনারের Web Service/API-এর ঠিকানা, পদ্ধতি ও Authentication সেটআপ করা হয় এবং পার্টনার থেকে সর্বশেষ পেমেন্ট স্ট্যাটাস সংগ্রহ করা হয়।":
 "Partner Web Service/API addresses, methods and authentication are configured, and the latest payment status is received from the partner.",
"অভিযোগ, সংশোধন, বাতিল ও ডকুমেন্টের অনুরোধ নিবন্ধন, পর্যালোচনা ও প্রক্রিয়া করা হয়।":
 "Complaints, corrections, cancellation and document requests are registered, reviewed and processed.",
"Central Admin, Exchange ও Agent-এর মধ্যে অভ্যন্তরীণ বার্তা আদান-প্রদান করা যায়।":
 "Internal messages can be exchanged between Central Admin, Exchanges and Agents.",
"নিয়ন্ত্রক সংস্থার জন্য প্রয়োজনীয় AML গ্রাহক ও লেনদেনের তথ্য এবং Compliance Review প্রয়োজন এমন লেনদেনের রিপোর্ট তৈরি করতে হয়।":
 "Required AML customer and transaction information for regulators, and reports of transactions needing compliance review, must be produced.",
"গ্রাহক, ট্রেড, বিশেষ ও ক্যাম্পেইন প্রোমোশন এবং প্রোমো-কোড/বোনাসের নিয়ম সেটআপ করা যায়।":
 "Consumer, trade, special and campaign promotions and promo-code/bonus rules can be set up.",
"রেমিট্যান্সের প্রতিটি স্ট্যাটাস পরিবর্তন উৎস ও সময়সহ সংরক্ষিত থাকে, যাতে পুরো ইতিহাস দেখা যায়।":
 "Every remittance status change is stored with its source and time, so the complete history can be viewed.",
"রেমিট্যান্স Export, তথ্য, ত্রুটি ও পেমেন্ট নিশ্চিতকরণ ফাইলের ফরম্যাট Administrator থেকে নির্ধারিত হয়।":
 "Remittance export, information, error and payment-confirmation file formats are configured by the Administrator.",
"দৈনিক, মাসিক ও বছরশেষের হিসাব সমাপ্তি (Closing) নির্দিষ্ট প্রক্রিয়ায় সম্পন্ন করতে হয়।":
 "Daily, monthly and year-end accounting closing must follow the defined process.",
"লেনদেন শুরুর আগে Remitter-এর তথ্য ও ডকুমেন্ট বৈধ আছে কিনা এবং Blacklist যাচাই সম্পন্ন হয়েছে কিনা নিশ্চিত হোন।":
 "Before starting a transaction, make sure the Remitter's details and documents are valid and the blacklist check is done.",
# ---- roles ----
"সকল ব্যবহারকারী": "All users", "Login, Logout, Password পরিবর্তনসহ সাধারণ কাজ সবার জন্য।": "General tasks such as login, logout and changing the password.",
"Head Office System Administrator": "Head Office System Administrator", "সিস্টেমের মূল সেটআপ, ইউজার, রেফারেন্স ডেটা ও Configuration পরিচালনা করেন।": "Manages core system setup, users, reference data and configuration.",
"Head Office (Central Admin) অপারেশন": "Head Office (Central Admin) operations", "TT নিয়ন্ত্রণ, পার্টনারে পাঠানো, দিনশেষ/মাসশেষের কাজ ও কেন্দ্রীয় রিপোর্ট।": "TT control, sending to partners, end-of-day/month-end work and central reports.",
"Compliance দল": "Compliance team", "AVR, কালো তালিকা, SOS ও নিয়ন্ত্রক রিপোর্ট দেখেন।": "Reviews AVR, blacklist, SOS and regulatory reports.",
"হিসাব / Finance বিভাগ": "Accounts / Finance department", "ভাউচার, খতিয়ান ও আর্থিক রিপোর্ট পরিচালনা করেন।": "Handles vouchers, ledgers and financial reports.",
"Exchange Administrator / Exchange User": "Exchange Administrator / Exchange User", "Exchange কোম্পানি পর্যায়ে ইউজার, ফ্রাঞ্চাইজি (Agent), চার্জ, লিমিট, TT নিয়ন্ত্রণ ও দিনশেষের কাজ করেন।": "Manages users, franchises (Agents), charges, limits, TT control and end-of-day work at Exchange-company level.",
"Agent / Franchise": "Agent / Franchise", "গ্রাহকের হয়ে লেনদেন পরিচালনা করেন।": "Handles transactions on behalf of customers.",
"Teller": "Teller", "কাউন্টারে Remitter, Beneficiary, TT Issue ও Payment-এর কাজ করেন।": "Handles Remitters, Beneficiaries, TT Issue and Payment at the counter.",
"অনুমোদিত Head Office ব্যবহারকারী": "Authorised Head Office users", "সার্ভিস প্যাক সেটআপ, লেনদেন ও রিপোর্ট।": "Service Pack setup, transactions and reports.",
"ব্যবস্থাপনা (Management)": "Management", "বাৎসরিক TT বিশ্লেষণ ও ডায়নামিক রিপোর্ট।": "Yearly TT analysis and dynamic reports.",
"খোলা উইন্ডোগুলো সাজানো বা বন্ধ করা।": "Arranges or closes open windows.",
# ---- results ----
"সব তথ্য সঠিকভাবে দিয়ে `Save` করলে তথ্য System-এ সংরক্ষিত হবে।": "When all details are entered correctly, `Save` stores the data in the system.",
"নির্বাচিত শর্ত অনুযায়ী তথ্য বা তালিকা উইন্ডোর টেবিলে দেখা যাবে।": "Data or a list matching the selected criteria is shown in the window's table.",
"`Preview`-তে রিপোর্টটি পর্দায় দেখা যাবে এবং `Print` দিয়ে প্রিন্ট করা যাবে।": "`Preview` shows the report on screen; `Print` prints it.",
"তথ্য বা ডকুমেন্ট ফাইল আকারে কম্পিউটারে নেওয়া (Export/Download) যাবে।": "Data or documents can be exported/downloaded to your computer as a file.",
"তালিকায় নতুন রেকর্ড যোগ, বিদ্যমান রেকর্ড সম্পাদনা বা মুছে ফেলা যাবে।": "You can add new records to the list, edit existing ones or delete them.",
"বার্তা বা তথ্য নির্ধারিত প্রাপকের কাছে পাঠানো হবে।": "The message or data is sent to the selected recipient.",
"অনুমোদন সম্পন্ন হলে সংশ্লিষ্ট রেকর্ড বা লেনদেনের স্ট্যাটাস পরিবর্তিত হবে।": "After authorisation, the status of the record or transaction changes.",
"নির্বাচিত প্রক্রিয়াটি সম্পন্ন হবে।": "The selected process is completed.",
"নির্বাচিত বিন্যাস অনুযায়ী খোলা উইন্ডোগুলো সাজানো (বা বন্ধ) হবে।": "Open windows are arranged (or closed) as selected.",
"নির্বাচিত Screen খুলবে এবং সংশ্লিষ্ট তথ্য দেখা যাবে।": "The selected screen opens and shows the related information.",
# ---- problems ----
"Remitter নির্বাচন করার পর লেনদেন এগোচ্ছে না": "The transaction does not proceed after selecting the Remitter",
"Remitter কালো তালিকায় (Blacklist) থাকলে লেনদেন প্রক্রিয়া করা যায় না। বিষয়টি Compliance দল বা Central Admin-কে জানান।": "A blacklisted Remitter cannot be processed. Inform the Compliance team or Central Admin.",
"রেট গ্রহণ করছে না": "The rate is not accepted",
"রেট নির্ধারিত সর্বনিম্ন/সর্বোচ্চ সীমার বাইরে হলে গ্রহণযোগ্য নয়। আজকের প্রকাশিত রেট ও Minimum and Maximum Rate দেখে নিন।": "Rates outside the configured minimum/maximum are rejected. Check today's published rate and the Minimum and Maximum Rate.",
"লেনদেন Hold অবস্থায় আটকে আছে": "The transaction is stuck on Hold",
"Hold-এর কারণ দেখে প্রয়োজনীয় তথ্য/ডকুমেন্ট দিন; সমস্যা সমাধানের পর অনুমোদিত ব্যবহারকারী Release করবেন।": "Check the hold reason and provide the required information/documents; an authorised user releases it once resolved.",
"বাতিল/সংশোধন সাথে সাথে কার্যকর হচ্ছে না": "Cancellation/correction does not take effect immediately",
"বাতিল ও সংশোধন অনুমোদনের পরেই সম্পন্ন হয়। আবেদন অনুমোদিত হয়েছে কিনা স্ট্যাটাস দেখে নিন।": "Cancellations and corrections complete only after approval. Check the status to see whether the request is approved.",
"লিমিট অতিক্রমের কারণে লেনদেন হচ্ছে না": "The transaction is blocked because a limit is exceeded",
"Remitter-এর দৈনিক, মাসিক ও বাৎসরিক লিমিট যাচাই করুন; প্রয়োজনে অনুমোদিত কর্তৃপক্ষের সাথে যোগাযোগ করুন।": "Check the Remitter's daily, monthly and yearly limits; contact the authorised person if needed.",
"তালিকা বা রিপোর্টে কোনো তথ্য আসছে না": "The list or report shows no data",
"তারিখের সীমা (Date range) এবং Company, Country, Franchise ইত্যাদি ফিল্টার ঠিকভাবে নির্বাচন করা হয়েছে কিনা দেখুন, তারপর আবার চেষ্টা করুন।": "Check that the date range and filters such as Company, Country and Franchise are set correctly, then try again.",
"Save করা যাচ্ছে না": "Save does not work",
"তারকা (*) চিহ্নিত বাধ্যতামূলক ঘরগুলো পূরণ হয়েছে কিনা এবং তারিখ/সংখ্যা সঠিক ফরম্যাটে আছে কিনা দেখুন।": "Check that all mandatory fields marked with an asterisk (*) are filled and that dates/numbers are in the correct format.",
"মেনুটি দেখা যাচ্ছে না বা খোলা যাচ্ছে না": "The menu is not visible or cannot be opened",
"মেনু দেখা যাওয়া ও ব্যবহার User Group-এর অনুমতির উপর নির্ভর করে। প্রয়োজন হলে Administrator-কে অনুমতি দিতে বলুন।": "Menu visibility and use depend on User Group permissions. Ask the Administrator to grant access if needed.",
}
