import re,json,glob,os,collections
SRC="/mnt/user-data/uploads/Documents/_claude_work"
# ---- menu tree from menu map ----
rows=[];sheet=None
for line in open(f"{SRC}/menu_map.tsv",encoding='utf-8'):
    line=line.rstrip('\n')
    if line.startswith('## SHEET'): sheet=line;continue
    c=line.split('\t')
    if len(c)>=8 and re.match(r'^\d+(\.\d+)*$',c[0]):
        rows.append(dict(code=c[0],type=c[6],path=c[7].strip(),notes=c[9] if len(c)>9 else ''))
print(len(rows),collections.Counter(r['type'] for r in rows))
json.dump(rows,open('menu.json','w'),ensure_ascii=False,indent=0)
# ---- manual blocks ----
def clean(t):
    t=t.replace('\\`','`').replace("\\'","'").replace('\\"','"').replace('\\#','#').replace('\\*','*').replace('\\[','[').replace('\\]',']').replace('\\_','_').replace('\\$','$').replace('\\|','|').replace('\\<','<').replace('\\>','>').replace('\\~','~')
    return t.strip()
blocks=[]
for f in sorted(glob.glob(f"{SRC}/*.md")):
    doc=os.path.basename(f)[:-3]
    lines=open(f,encoding='utf-8').read().split('\n')
    head=[];cur=None
    i=0
    while i<len(lines):
        l=lines[i]
        nxt=lines[i+1] if i+1<len(lines) else ''
        if l.strip() and re.match(r'^(=+|-+)\s*$',nxt) and not l.startswith('!['):
            head=clean(re.sub(r'\[(.*?)\]\{[^}]*\}',r'\1',l)); blocks.append(dict(doc=doc,kind='h',text=head)); i+=2; continue
        m=re.match(r'^#+\s+(.*)',l)
        if m: blocks.append(dict(doc=doc,kind='h',text=clean(m.group(1))));i+=1;continue
        for im in re.findall(r'!\[[^\]]*\]\((media/[^)]+)\)',l):
            blocks.append(dict(doc=doc,kind='img',src=im))
        rest=re.sub(r'!\[[^\]]*\]\([^)]+\)(\{[^}]*\})?','',l).strip()
        if rest: blocks.append(dict(doc=doc,kind='p',text=clean(rest)))
        i+=1
json.dump(blocks,open('blocks.json','w'),ensure_ascii=False)
print(collections.Counter(b['kind'] for b in blocks))
