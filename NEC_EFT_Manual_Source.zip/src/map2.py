import json,re,collections
B=json.load(open('blocks.json')); M=json.load(open('menu.json'))
P={r['path']:r for r in M if r['path']}
kids=collections.defaultdict(list)
for p in P:
    if ' › ' in p: kids[p.rsplit(' › ',1)[0]].append(p.rsplit(' › ',1)[1])
ROOTS=[p for p in P if ' › ' not in p]
def walk(txt,pos):
    # txt[pos:] starts with a root name
    best=None
    for r in ROOTS:
        if txt[pos:pos+len(r)].lower()==r.lower(): best=r
    if not best: return None
    cur=best; i=pos+len(best)
    while True:
        m=re.match(r'\s*›\s*',txt[i:])
        if not m: break
        j=i+m.end(); ch=None
        for k in kids.get(cur,[]):
            if txt[j:j+len(k)].lower()==k.lower() and (ch is None or len(k)>len(ch)): ch=k
        if not ch:
            # tolerate small diffs: normalized compare
            seg=re.split(r'`|-এ|-এর|---|"|\(|।|,|;',txt[j:])[0].strip()
            n=re.sub(r'\W','',seg.lower())
            for k in kids.get(cur,[]):
                if re.sub(r'\W','',k.lower())==n: ch=k; j=j; i2=j+len(seg); break
            if not ch: break
            cur=cur+' › '+ch; i=i2; continue
        cur=cur+' › '+ch; i=j+len(ch)
    return cur
def crumbs(txt):
    res=[]
    for m in re.finditer(r'(File|Administrator|Central Admin|General Ledger|Exchange|Agency|Service Pack|Management Reports|Windows)((?:\s*›\s*[^›]+?)*)\s*(?:মেনুতে|মেনুর|সাব-মেনুতে)\s+`?([^`]+?)`?\s+(?:অপশন|মেনু|সাব)',txt):
        w=walk(txt,m.start())
        if w:
            leafn=m.group(3).strip()
            for k in kids.get(w,[]):
                if k.lower()==leafn.lower(): res.append(w+' › '+k)
    for m in re.finditer(r'(File|Administrator|Central Admin|General Ledger|Exchange|Agency|Service Pack|Management Reports|Windows)\s*›',txt):
        w=walk(txt,m.start())
        if w: res.append(w)
    return res
leaf=collections.defaultdict(list)
for p in P: leaf[re.sub(r'\W','',p.rsplit(' › ',1)[-1].lower())].append(p)
def sim(a,b):
    s=0
    for x,y in zip(a.split(' › '),b.split(' › ')):
        if x==y: s+=1
        else: break
    return s
def leafmatch(txt,ctx,doc):
    m=re.match(r'^\**`?["“]?([^`"”\n]+?)["”]?`?\s*-?(?:এ|তে|এর|-এ)\s',txt) or re.match(r'^\**`([^`]+)`',txt)
    if not m: return None
    n=re.sub(r'\W','',m.group(1).split('›')[-1].lower())
    c=leaf.get(n,[])
    if not c: return None
    return max(c,key=lambda x:(sim(x,ctx or ''),0))
out=[];ctx=None
for i,b in enumerate(B):
    if b['kind']=='h':
        t=re.sub(r'\[|\]|\{.*?\}|→ open tab|\(\?tab=[^)]*\)','',b['text'])
        t=re.sub(r'^[^A-Za-z]+','',t).strip()
        c=leaf.get(re.sub(r'\W','',t.lower()),[])
        if c: ctx=max(c,key=lambda x:sim(x,ctx or ''))
        continue
    if b['kind']!='img': continue
    desc=[];j=i+1
    while j<len(B) and B[j]['kind']=='p':
        t=B[j]['text']
        if not re.match(r'^(\(Screenshot|\*\*🖼|\*\(Ekhane|-\s+\[)',t): desc.append(t.strip('*'))
        j+=1
    d=' '.join(desc)
    cs=crumbs(d)
    if b['doc'].startswith('4.'):
        cs=[('Exchange › '+c if c.startswith('General Ledger') and ('Exchange › '+c) in P else c) for c in cs]
    if cs:
        p=max(cs,key=lambda x:x.count('›')); how='crumb'
    else:
        p=leafmatch(d,ctx,b['doc']); how='leaf' if p else 'ctx'
        if not p: p=ctx
    if how!='ctx': ctx=p
    out.append(dict(doc=b['doc'],src=b['src'],desc=d,path=p,how=how))
json.dump(out,open('imgs.json','w'),ensure_ascii=False,indent=0)
print(collections.Counter(o['how'] for o in out),'unmapped',sum(1 for o in out if not o['path']))
cov=collections.Counter(o['path'] for o in out if o['path'])
scr=[r['path'] for r in M if r['type']=='Screen']
print('screens with imgs',sum(1 for s in scr if s in cov),'/',len(scr))
print('nonscreen',sorted(((cov[p],p) for p in cov if P[p]['type']!='Screen'),reverse=True)[:30])
miss=[s for s in scr if s not in cov]; json.dump(miss,open('missing.json','w'),ensure_ascii=False,indent=0)
print(collections.Counter(m.split(' › ')[0] for m in miss))
