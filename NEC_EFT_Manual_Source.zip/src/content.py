# -*- coding: utf-8 -*-
"""Rule tables used to build each feature page. Every business-rule note cites the
HLBR requirement / rule ID it comes from; anything not backed by a source is flagged guess=True."""
import re

ROLES = {
 "File": [("সকল ব্যবহারকারী","Login, Logout, Password পরিবর্তনসহ সাধারণ কাজ সবার জন্য।")],
 "Administrator": [("Head Office System Administrator","সিস্টেমের মূল সেটআপ, ইউজার, রেফারেন্স ডেটা ও Configuration পরিচালনা করেন।")],
 "Central Admin": [("Head Office (Central Admin) অপারেশন","TT নিয়ন্ত্রণ, পার্টনারে পাঠানো, দিনশেষ/মাসশেষের কাজ ও কেন্দ্রীয় রিপোর্ট।"),("Compliance দল","AVR, কালো তালিকা, SOS ও নিয়ন্ত্রক রিপোর্ট দেখেন।")],
 "General Ledger": [("হিসাব / Finance বিভাগ","ভাউচার, খতিয়ান ও আর্থিক রিপোর্ট পরিচালনা করেন।")],
 "Exchange": [("Exchange Administrator / Exchange User","Exchange কোম্পানি পর্যায়ে ইউজার, ফ্রাঞ্চাইজি (Agent), চার্জ, লিমিট, TT নিয়ন্ত্রণ ও দিনশেষের কাজ করেন।")],
 "Agency": [("Agent / Franchise","গ্রাহকের হয়ে লেনদেন পরিচালনা করেন।"),("Teller","কাউন্টারে Remitter, Beneficiary, TT Issue ও Payment-এর কাজ করেন।")],
 "Service Pack": [("অনুমোদিত Head Office ব্যবহারকারী","সার্ভিস প্যাক সেটআপ, লেনদেন ও রিপোর্ট।")],
 "Management Reports": [("ব্যবস্থাপনা (Management)","বাৎসরিক TT বিশ্লেষণ ও ডায়নামিক রিপোর্ট।")],
 "Windows": [("সকল ব্যবহারকারী","খোলা উইন্ডোগুলো সাজানো বা বন্ধ করা।")],
}

# (regex on path+descriptions, kind, Bangla note, source IDs)
NOTES = [
 (r"Black ?List", "rule", "কালো তালিকাভুক্ত (Blacklist) ব্যক্তি যাচাই রেমিট্যান্স নিয়ন্ত্রণের অংশ। লেনদেন প্রক্রিয়ার আগে Agency-কে Remitter কালো তালিকায় আছে কিনা যাচাই করতে হয়।", "BR-004 · AGY-009 · CADM-010 · EXC-024"),
 (r"\bAVR\b", "rule", "উচ্চ-ঝুঁকির রেমিট্যান্সে AVR (Adeguata Verifica Rafforzata — বাড়তি যাচাই) তথ্য দিতে হয় এবং Export-এর আগে লেনদেনটি Review-এর জন্য Hold থাকতে পারে।", "BR-005 · AGY-015 · EXC-026 · CADM-011"),
 (r"Minimum and Maximum|Dealing Rate|Today's Rate|Base Rate|Export Rate|Public Currency|currency rate|Rate Parameter", "rule", "লেনদেনের Exchange Rate (মুদ্রা বিনিময় হার) অবশ্যই নির্ধারিত সর্বনিম্ন ও সর্বোচ্চ সীমার মধ্যে থাকতে হবে। অনুমোদিত রেট প্রকাশের পরেই Agency রেমিট্যান্স শুরু করে।", "BR-002 · CADM-021 · CADM-022 · EXC-015 · AGY-002"),
 (r"Limit", "rule", "Remitter-এর লেনদেন সীমা দিন, মাস ও বছর অনুযায়ী যাচাই হয়; লেনদেন, Remitter ও Beneficiary-র সীমা Administrator নির্ধারণ করেন।", "BR-003 · ADM-005 · CADM-009 · EXC-014"),
 (r"Cancel|Refund|Correction", "warn", "TT বাতিল (Cancellation) ও সংশোধন (Correction) সম্পন্ন করার আগে পর্যালোচনা ও অনুমোদন প্রয়োজন। অনুমোদনের পরেই Agency গ্রাহককে টাকা ফেরত (Refund) দেয়।", "BR-009 · AGY-012 · AGY-013 · CADM-035 · CADM-036 · EXC-023"),
 (r"Authorise TT|Unauthorise TT|Change Bank Branch|Sending of TT|Undo Send|Resend TT", "warn", "কোনো TT-র কোম্পানি, ব্যাংক বা প্রসেসিং স্ট্যাটাস পরিবর্তনের আগে Central Admin-এর অনুমোদন প্রয়োজন।", "BR-008 · CADM-027 · CADM-028 · CADM-031"),
 (r"Hold|Unhold", "info", "কোনো সমস্যা থাকলে রেমিট্যান্স Hold করা হয় এবং সমস্যা সমাধানের পর Release করা হয়। Agency Hold থাকা লেনদেন ও তার কারণ দেখতে পারে।", "CADM-029 · EXC-018 · AGY-014"),
 (r"Mac Address|Mac Query", "rule", "Agent-এর লেনদেন শুধু অনুমোদিত (MAC/IP দ্বারা চিহ্নিত) কম্পিউটার থেকে করা যায়।", "BR-007 · CADM-055 · EXC-028"),
 (r"Journal Voucher|Cash Payment|Cash Receipt|Bank Payment|Bank Receipt|Cash Receive|Bank Receive|Opening Balance|Special Transaction|Authorise Franchise Deposit|Authorize Exchange Deposits", "rule", "হিসাবের ভাউচার General Ledger-এ পোস্ট করার আগে যাচাই ও যথাযথ অনুমোদন প্রয়োজন।", "BR-001 · ACC-004 · ACC-022"),
 (r"Document", "info", "Remitter ও Agent-এর ডকুমেন্টের মেয়াদ ও অবস্থা (missing, uploaded, expired) ট্র্যাক করা হয়।", "BR-006 · DOC-002 · EXC-029 · CADM-047"),
 (r"Remitter Authorisation|Remitter Txn Authorisation", "rule", "নতুন তৈরি বা পরিবর্তিত Remitter-এর তথ্য Review ও অনুমোদন করতে হয়।", "CADM-056 · EXC-019"),
 (r"› Users$|› Groups$|Access Log|Menu Setting|Login Log|User Management", "info", "প্রত্যেক ইউজার শুধু নিজের User Group-এ দেওয়া অনুমতি অনুযায়ী মেনু ও কাজ ব্যবহার করতে পারেন। লগইন প্রচেষ্টা, ডিভাইস, IP ও প্রবেশ প্রত্যাখ্যানের কারণ রেকর্ড রাখা হয়।", "ADM-002 · ADM-007 · ADM-010 · SEC-001"),
 (r"Duplicate|Merge|Edit/Delete", "warn", "ডুপ্লিকেট Remitter/Beneficiary রেকর্ড সম্পাদনা, মুছে ফেলা বা একীকরণ (Merge) যথাযথ নিয়ন্ত্রণের অধীনে করতে হয়।", "CADM-034 · EXC-020"),
 (r"Coverfund", "info", "Coverfund হলো Payout পার্টনারকে লেনদেন পরিশোধের জন্য আগাম পাঠানো অর্থ। দৈনিক Coverfund পরিমাণ, রূপান্তর হার ও এক্সচেঞ্জ আয় হিসাব করা হয়।", "TRY-001 · CADM-038 · EXC-031"),
 (r"End of Day|Closing of Franchise|Day End|day end", "info", "দিনশেষে টেলার ও মুদ্রাভিত্তিক সারসংক্ষেপ তৈরি এবং Agent-এর দৈনিক অবস্থান (Position) হিসাব করা হয়।", "CADM-037 · EXC-030 · AGY-023"),
 (r"Income Sharing|Month End", "info", "মাসিক আয় ভাগাভাগি (Income Sharing) প্রক্রিয়া করা হয় এবং অনুমোদিত সংশোধন প্রয়োজন হলে আবার চালানো যায়।", "CADM-042 · EXC-034"),
 (r"Charge|Commission|Sharing|Bonus", "info", "চার্জ নির্দিষ্ট (Fixed) বা স্ল্যাব-ভিত্তিক হতে পারে; চার্জ, কমিশন ও আয় Exchange, Agent ও অন্যান্য পক্ষের মধ্যে নির্ধারিত নিয়মে ভাগ হয়।", "ADM-031 · ADM-032 · EXC-009 · EXC-010"),
 (r"UIC", "info", "UIC (Unique Identification Code) রেফারেন্স ডেটা — অবস্থান, ব্যবসায়িক খাত, ঝুঁকির শ্রেণি, তৃতীয় পক্ষের সম্পর্ক ও গ্রহণযোগ্য ডকুমেন্টের ধরন — গ্রাহককে সঠিকভাবে শনাক্ত ও শ্রেণিবদ্ধ করতে ব্যবহৃত হয়।", "ADM-012"),
 (r"Holiday", "info", "দেশভিত্তিক ছুটির তালিকা দৈনন্দিন কার্যক্রমে ব্যবহৃত হয়।", "ADM-003"),
 (r"Testkey", "rule", "API ছাড়া ফাইলের মাধ্যমে যুক্ত পার্টনারের রেমিট্যান্স ফাইলের জন্য নিরাপত্তা কী (Testkey) ব্যবহৃত হয়।", "ADM-018 · CADM-033"),
 (r"WS Function|Webhook|Api Integration|From WS", "info", "পার্টনারের Web Service/API-এর ঠিকানা, পদ্ধতি ও Authentication সেটআপ করা হয় এবং পার্টনার থেকে সর্বশেষ পেমেন্ট স্ট্যাটাস সংগ্রহ করা হয়।", "ADM-028 · CADM-032"),
 (r"Complain", "info", "অভিযোগ, সংশোধন, বাতিল ও ডকুমেন্টের অনুরোধ নিবন্ধন, পর্যালোচনা ও প্রক্রিয়া করা হয়।", "CADM-058 · EXC-044 · AGY-029"),
 (r"Messag", "info", "Central Admin, Exchange ও Agent-এর মধ্যে অভ্যন্তরীণ বার্তা আদান-প্রদান করা যায়।", "CADM-059 · EXC-045 · AGY-030"),
 (r"SOS|Comunicazione|Compliance Report|Transfer data to MIT|Transfer Data to Central Bank", "rule", "নিয়ন্ত্রক সংস্থার জন্য প্রয়োজনীয় AML গ্রাহক ও লেনদেনের তথ্য এবং Compliance Review প্রয়োজন এমন লেনদেনের রিপোর্ট তৈরি করতে হয়।", "EXC-027 · AGY-016 · AGY-017 · CADM-008"),
 (r"Promotion|Promo|Point", "info", "গ্রাহক, ট্রেড, বিশেষ ও ক্যাম্পেইন প্রোমোশন এবং প্রোমো-কোড/বোনাসের নিয়ম সেটআপ করা যায়।", "CADM-016 · CADM-017 · CADM-018"),
 (r"Status History|Edit History|Hold/Cancel Applied", "info", "রেমিট্যান্সের প্রতিটি স্ট্যাটাস পরিবর্তন উৎস ও সময়সহ সংরক্ষিত থাকে, যাতে পুরো ইতিহাস দেখা যায়।", "BR-011 · BR-015 · CADM-048"),
 (r"File Format|Export File|Import .*File|Confirmation File", "info", "রেমিট্যান্স Export, তথ্য, ত্রুটি ও পেমেন্ট নিশ্চিতকরণ ফাইলের ফরম্যাট Administrator থেকে নির্ধারিত হয়।", "ADM-027"),
 (r"Year End|Closing of Company|Finalize Company", "warn", "দৈনিক, মাসিক ও বছরশেষের হিসাব সমাপ্তি (Closing) নির্দিষ্ট প্রক্রিয়ায় সম্পন্ন করতে হয়।", "ACC-018"),
 (r"TT Issue$|New Remitter|New Beneficiary", "info", "লেনদেন শুরুর আগে Remitter-এর তথ্য ও ডকুমেন্ট বৈধ আছে কিনা এবং Blacklist যাচাই সম্পন্ন হয়েছে কিনা নিশ্চিত হোন।", "AGY-006 · AGY-009 · AGY-010"),
]

def notes_for(path, text):
    hay = path + " " + text
    out = []
    for rx, kind, t, src in NOTES:
        if re.search(rx, path) or (re.search(rx, text) and len(out) < 2 and kind == "rule"):
            out.append(dict(k=kind, t=t, s=src))
        if len(out) >= 4: break
    return out

def problems_for(path, text, buttons):
    P = []
    leaf = path.split(" › ")[-1]
    if re.search(r"Black ?List", path + text):
        P.append(("Remitter নির্বাচন করার পর লেনদেন এগোচ্ছে না", "Remitter কালো তালিকায় (Blacklist) থাকলে লেনদেন প্রক্রিয়া করা যায় না। বিষয়টি Compliance দল বা Central Admin-কে জানান।", "BR-004 · AGY-009", False))
    if re.search(r"Rate", path):
        P.append(("রেট গ্রহণ করছে না", "রেট নির্ধারিত সর্বনিম্ন/সর্বোচ্চ সীমার বাইরে হলে গ্রহণযোগ্য নয়। আজকের প্রকাশিত রেট ও Minimum and Maximum Rate দেখে নিন।", "BR-002", False))
    if re.search(r"Hold", path):
        P.append(("লেনদেন Hold অবস্থায় আটকে আছে", "Hold-এর কারণ দেখে প্রয়োজনীয় তথ্য/ডকুমেন্ট দিন; সমস্যা সমাধানের পর অনুমোদিত ব্যবহারকারী Release করবেন।", "CADM-029 · AGY-014", False))
    if re.search(r"Cancel|Correction|Refund", path):
        P.append(("বাতিল/সংশোধন সাথে সাথে কার্যকর হচ্ছে না", "বাতিল ও সংশোধন অনুমোদনের পরেই সম্পন্ন হয়। আবেদন অনুমোদিত হয়েছে কিনা স্ট্যাটাস দেখে নিন।", "BR-009", False))
    if re.search(r"Limit", path):
        P.append(("লিমিট অতিক্রমের কারণে লেনদেন হচ্ছে না", "Remitter-এর দৈনিক, মাসিক ও বাৎসরিক লিমিট যাচাই করুন; প্রয়োজনে অনুমোদিত কর্তৃপক্ষের সাথে যোগাযোগ করুন।", "BR-003", False))
    if any(b in buttons for b in ("Preview", "Print", "Search", "Refresh", "Load now", "Reload")):
        P.append(("তালিকা বা রিপোর্টে কোনো তথ্য আসছে না", "তারিখের সীমা (Date range) এবং Company, Country, Franchise ইত্যাদি ফিল্টার ঠিকভাবে নির্বাচন করা হয়েছে কিনা দেখুন, তারপর আবার চেষ্টা করুন।", "", True))
    if "Save" in buttons:
        P.append(("Save করা যাচ্ছে না", "তারকা (*) চিহ্নিত বাধ্যতামূলক ঘরগুলো পূরণ হয়েছে কিনা এবং তারিখ/সংখ্যা সঠিক ফরম্যাটে আছে কিনা দেখুন।", "", True))
    P.append(("মেনুটি দেখা যাচ্ছে না বা খোলা যাচ্ছে না", "মেনু দেখা যাওয়া ও ব্যবহার User Group-এর অনুমতির উপর নির্ভর করে। প্রয়োজন হলে Administrator-কে অনুমতি দিতে বলুন।", "ADM-002 · ADM-007", False))
    seen = set(); out = []
    for q, a, s, g in P:
        if q in seen: continue
        seen.add(q); out.append(dict(q=q, a=a, s=s, g=g))
    return out[:4]

BTN_RESULT = [
 (("Save",), "সব তথ্য সঠিকভাবে দিয়ে `Save` করলে তথ্য System-এ সংরক্ষিত হবে।"),
 (("Search", "Refresh", "Load now", "Reload", "Load", "Show"), "নির্বাচিত শর্ত অনুযায়ী তথ্য বা তালিকা উইন্ডোর টেবিলে দেখা যাবে।"),
 (("Preview",), "`Preview`-তে রিপোর্টটি পর্দায় দেখা যাবে এবং `Print` দিয়ে প্রিন্ট করা যাবে।"),
 (("Export", "Export to Excel", "Download"), "তথ্য বা ডকুমেন্ট ফাইল আকারে কম্পিউটারে নেওয়া (Export/Download) যাবে।"),
 (("Add", "Edit", "Delete", "New"), "তালিকায় নতুন রেকর্ড যোগ, বিদ্যমান রেকর্ড সম্পাদনা বা মুছে ফেলা যাবে।"),
 (("Send",), "বার্তা বা তথ্য নির্ধারিত প্রাপকের কাছে পাঠানো হবে।"),
 (("Authorise", "Authorize", "Approve"), "অনুমোদন সম্পন্ন হলে সংশ্লিষ্ট রেকর্ড বা লেনদেনের স্ট্যাটাস পরিবর্তিত হবে।"),
 (("Process", "Process Now"), "নির্বাচিত প্রক্রিয়াটি সম্পন্ন হবে।"),
]
