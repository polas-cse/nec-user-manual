# NEC EFT Bangla User Manual — build source

The deliverable `NEC_EFT_User_Manual_Bangla.html` is one standalone offline file (HTML5 + CSS3 + vanilla JS,
images embedded as base64 WebP, Hind Siliguri font embedded). These scripts regenerate it.

Pipeline
1. `parse.py`   — reads the pandoc-markdown export of the 10 "Features Extract and Explanation" docx files and the
                 Menu Map xlsx (exported as TSV) → `menu.json`, `blocks.json`.
2. `map2.py`    — matches every screenshot + its Bangla description to a Menu Map path → `imgs.json`.
3. `late.py`    — 5 Nov 2026 screenshots not present in the docx files, with Bangla descriptions written from the images.
4. `bn_names.py`— Bangla name for every one of the 442 menu labels.
5. `content.py` — role, business-rule (HLBR IDs) and problem/solution tables.
6. `build.py`   — builds per-page JSON (`data.json`) and the deduplicated image set (`imgdata.json`).
7. `assemble.py`— injects data, images and font into `template.html` → final HTML.

Images: docx media + late PNGs converted to WebP (max width 1400 px, quality 62) before step 6.
