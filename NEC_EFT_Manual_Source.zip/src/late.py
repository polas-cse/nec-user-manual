import json
L=[
("Agency › Franchise Report › Teller Supplementary",[
 ("150617","`Agency › Franchise Report`-এ মাউস হোভার করলে সাব-মেনুগুলো দেখা যায় — Current Position, Summary and Detail Report, Franchise Position, General Supplementary, Teller Supplementary, Day wise Summary, Franchise Balance, Franchise Comission/Earning, Franchise Rate Change History, Franchise wise Report (Summary) ও Franchise wise Report (Detail); এখানে Teller Supplementary হাইলাইট করা আছে।"),
 ("150632","`Teller Supplementary`-এ ক্লিক করলে \"Teller wise supplementary\" উইন্ডো খুলে যায়, যেখানে TT Issue, TT Issue V2, TT Payment ও Cash in dollar — এই অপশনগুলোর একটি বেছে নিতে হয়; Teller name (যেমন DEV_RONY) ও Supplementary as on (তারিখ) দিয়ে `Preview` বা `Print` বাটনে ক্লিক করতে হয়, `Close` দিয়ে উইন্ডো বন্ধ হয়।"),
 ("150637","`Preview`-তে ক্লিক করলে \"Supplementary of TT issue\" রিপোর্ট দেখা যায়, যেখানে Exchange, Franchise, Teller ও Report date-এর নিচে Remittance No, Remitter's Particular (ID, Name), Beneficiary's Particular (Name, Account/Secret no, Bank/Doc no, Branch/Address), Remittance Amount এবং Amount Received (TT Amount, Comm, Tax, Total) কলামে প্রতিটি TT-র তথ্য ও শেষে মোট যোগফল থাকে।")]),
("Agency › Franchise Report › Day wise Summary",[
 ("150650","`Agency › Franchise Report › Day wise Summary` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150701","`Day wise Summary`-তে ক্লিক করলে \"Day wise summary\" উইন্ডো খুলে যায়, যেখানে Company (<All Companies>), Country (<All Countries>), Currency (<All Currencies>) ও Date range (যেমন 01 Nov 2024 থেকে 22 Nov 2024) নির্বাচন করে `Preview` বা `Print` করা যায়।"),
 ("150707","`Preview`-তে ক্লিক করলে \"Day wise summary\" রিপোর্ট দেখা যায়, যেখানে প্রতিটি Issue date অনুযায়ী Country, Currency, No of TT, Benef Amount, Euro Amount ও Euro Commission কলামে দেশভিত্তিক সারসংক্ষেপ এবং প্রতিদিনের মোট যোগফল থাকে।")]),
("Agency › Franchise Report › Franchise Balance",[
 ("150717","`Agency › Franchise Report › Franchise Balance` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150731","`Franchise Balance`-এ ক্লিক করলে \"Franchise wise report (Summary)\" উইন্ডো খুলে যায়, যেখানে Exchange ID (NEC), Subcompanies তালিকা (Code, Name, Mode), Franchise ID (যেমন NEC 0017 — PRINCIPAL BRANCH), Begin date ও End date এবং ডান পাশে Balance বা Detail Balance অপশন থাকে; `Preview`, `Print` ও `Close` বাটন আছে।"),
 ("150735","`Preview`-তে ক্লিক করলে \"Franchise Balance\" রিপোর্ট দেখা যায়, যেখানে Date, Description, Debit, Credit, Debit Balance ও Credit Balance কলামে ফ্রাঞ্চাইজির প্রতিটি লেনদেন (যেমন TT Issue-এর জন্য ডেবিট, Bank deposit-এর জন্য ক্রেডিট) এবং চলমান ব্যালান্স দেখা যায়।")]),
("Agency › Franchise Report › Franchise Comission/Earning",[
 ("150745","`Agency › Franchise Report › Franchise Comission/Earning` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150756","`Franchise Comission/Earning`-এ ক্লিক করলে \"Franchise charge payment\" উইন্ডো খুলে যায়, যেখানে Exchange ID (NEC), Status (Active), For the Month of (যেমন Nov 2024) এবং Franchise code ও Franchise Name-এর তালিকা থাকে; `Preview`, `Print`, `Detail`, `Summary` ও `Close` বাটন দিয়ে রিপোর্ট দেখা বা প্রিন্ট করা যায়।")]),
("Agency › Franchise Report › Franchise Rate Change History",[
 ("150805","`Agency › Franchise Report › Franchise Rate Change History` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150814","`Franchise Rate Change History`-তে ক্লিক করলে \"Agency Rate Change History\" উইন্ডো খুলে যায়, যেখানে Exchange ID, Franchise ID (NEC 0017 — PRINCIPAL BRANCH), Begin date ও End date দিয়ে `Preview` বা `Print` করা যায়।"),
 ("150818","`Preview`-তে ক্লিক করলে \"Franchise rate change history\" রিপোর্ট দেখা যায়, যেখানে Remittance No, Issue Date, Exported Date, Payee Mode, Beneficiary Amount, Public Rate, Rate Given, TT Amount, PD Amount, Rate Payable, Other Charge, Commission ও Cancelled/Refunded Date কলাম থাকে।")]),
("Agency › Franchise Report › Franchise wise Report (Summary)",[
 ("150826","`Agency › Franchise Report › Franchise wise Report (Summary)` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150837 (1)","`Franchise wise Report (Summary)`-তে ক্লিক করলে \"Franchise wise report (Summary)\" উইন্ডো খুলে যায়, যেখানে Subcompanies তালিকা, Franchise ID, Begin date ও End date এবং ডান পাশে রিপোর্টের ধরন — TT Issue, TT Issue Rate wise, TT Payment, TT Cancellation (Before send), TT Cancellation (After send) ও Bank/Cash deposit — বেছে নিয়ে `Preview` বা `Print` করা যায়।")]),
("Agency › Franchise Report › Franchise wise Report (Detail)",[
 ("150855","`Agency › Franchise Report › Franchise wise Report (Detail)` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150904","`Franchise wise Report (Detail)`-এ ক্লিক করলে \"Franchise wise report (Detail)\" উইন্ডো খুলে যায়, যেখানে Subcompanies তালিকা, Franchise ID, Begin date ও End date এবং ডান পাশে TT Issue (Issue date / Exported date), TT Payment, TT Cancellation, Payment Cancellation ও Cancellation status অপশন থাকে; `Preview`, `Print` ও `Close` বাটন আছে।")]),
("Agency › Complain › Send Complain",[
 ("150913","`Agency › Complain`-এ মাউস হোভার করলে Send Complain ও View Report সাব-মেনু দেখা যায়; এখানে Send Complain হাইলাইট করা।"),
 ("150921","`Send Complain`-এ ক্লিক করলে \"Beneficiary complain\" উইন্ডো খুলে যায়। Search criteria অংশে Exchange company, Franchise, Corresponding companies ও Issue date range থাকে; এরপর Beneficiary (Surname or Name), Beneficiary Account No, Beneficiary phone no, Remitter (Surname or Name), Remitter date of birth, Remitter ID, Order no, Remittance no, Secret no/Password বা Ref number — এর একটি বেছে Criteria (LIKE) ও Value দিয়ে `Search` করতে হয়। ফলাফলের টেবিলে Remittance no, Order no, Issue date, Remitter ID, Remitter Full Name ও Beneficiary Full Name দেখা যায়; নিচে Complain type ও Complain detail লিখে `Save` করতে হয়।")]),
("Agency › Complain › View Report",[
 ("150928","`Agency › Complain › View Report` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("150935","`View Report`-এ ক্লিক করলে \"Complain status history\" উইন্ডো খুলে যায়, যেখানে All Companies, All exchanges, All Franchises, Complain date range বা Report entry date range এবং Remitter ID, Order no বা Remittance no দিয়ে `Search` করা যায়; বাম পাশে Remittance no, Order no ও Complain তালিকা এবং ডান পাশে Remitter, Amount, Issue date, Previous ও Current details এবং Entry Time, Entry User, Confirmed, Status Date, Document No ও Status দেখা যায়।")]),
("Agency › Messaging › Send Message",[
 ("150942","`Agency › Messaging`-এ মাউস হোভার করলে Send Message ও View Message সাব-মেনু দেখা যায়।"),
 ("150950","`Send Message`-এ ক্লিক করলে \"Send Message\" উইন্ডো খুলে যায়, যেখানে Message বক্সে বার্তা লিখে Send message to (Head Office বা Exchange), Effect on (তারিখ) ও Priority (Normal, Medium বা High) নির্বাচন করে `Send` বাটনে ক্লিক করতে হয়।")]),
("Agency › Messaging › View Message",[
 ("150958","`Agency › Messaging › View Message` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("151009","`View Message`-এ ক্লিক করলে \"View Messages\" উইন্ডো খুলে যায়, যেখানে Message(s) of (যেমন <SENT ITEMS>), Message date range ও Message category (All) দিয়ে `Search` করা যায়; টেবিলে Sender, Message, Sent date, Priority, Comments ও Read time দেখা যায় এবং `Delete`, `Preview` ও `Close` বাটন আছে।")]),
("Agency › Agent Documents › Circolare",[
 ("151017","`Agency › Agent Documents`-এ মাউস হোভার করলে Circolare, Documenti AML, Documenti Trasparenza ও Privacy সাব-মেনু দেখা যায়।"),
 ("151032","`Circolare`-তে ক্লিক করলে \"List of existing documents (Circolare)\" উইন্ডো খুলে যায়, যেখানে Sl ও File name কলামে সার্কুলার PDF ফাইলগুলোর তালিকা (যেমন Privacy, Contratto, AML সার্কুলার) থাকে; ফাইল নির্বাচন করে `Download` করা যায়, `Refresh` দিয়ে তালিকা হালনাগাদ হয়।")]),
("Agency › Agent Documents › Documenti AML",[
 ("151041","`Agency › Agent Documents › Documenti AML` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("151055","`Documenti AML`-এ ক্লিক করলে \"List of existing documents (Documenti AML)\" উইন্ডো খুলে যায়, যেখানে AML সংক্রান্ত নির্দেশিকা ও ফর্মের PDF তালিকা (যেমন Istruzioni Antiriciclaggio, Modulo identificazione e adeguata verifica, Modulo Sos, Procedura PEP) থাকে; `Refresh`, `Download` ও `Close` বাটন আছে।")]),
("Agency › Agent Documents › Documenti Trasparenza",[
 ("151104","`Agency › Agent Documents › Documenti Trasparenza` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("151124","`Documenti Trasparenza`-তে ক্লিক করলে \"List of existing documents (Documenti Trasparenza)\" উইন্ডো খুলে যায়, যেখানে স্বচ্ছতা (Transparency) সংক্রান্ত PDF তালিকা (যেমন Condizioni generali di contratto, Diritti del cliente, Foglio informativo, Guida ABF) থাকে; `Refresh`, `Download` ও `Close` বাটন আছে।")]),
("Agency › Agent Documents › Privacy",[
 ("151133","`Agency › Agent Documents › Privacy` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("151147","`Privacy`-তে ক্লিক করলে \"List of existing documents (Privacy)\" উইন্ডো খুলে যায়; এই Screenshot-এ তালিকাটি খালি, অর্থাৎ কোনো Privacy ডকুমেন্ট আপলোড করা নেই, তাই `Download` বাটন নিষ্ক্রিয়।")]),
("Agency › Contact us",[
 ("151154","`Agency › Contact us` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("151206","`Contact us`-এ ক্লিক করলে \"About us\" উইন্ডো খুলে যায়, যেখানে Exchange ID (NEC) ও Name-এর নিচে অফিসের Phone ও Fax, Complain নম্বর (Srilanka, SUD America), ইমেইল ঠিকানা, HELPLINE নম্বর, অ্যাপ্লিকেশনের ওয়েব ঠিকানা এবং Compliance ও Fiscal ইমেইল দেখা যায়।")]),
("Service Pack › Setup › Marking of Bank to Transfer Exchange Earning",[
 ("151440","`Service Pack › Setup`-এ মাউস হোভার করলে সাব-মেনুগুলো দেখা যায় — Marking of Bank to Transfer Exchange Earning, Transfer Exchange Earning Percentage Setup, Company, Remitter, Beneficiary, Otp Scheme ও Otp Validation।"),
 ("151958","`Marking of Bank to Transfer Exchange Earning`-এ ক্লিক করলে \"Marking Company for exchange earning transfer\" উইন্ডো খুলে যায়, যেখানে Company Name, Country ও Coverfund Currency কলামে Correspondent Company-গুলোর তালিকা থাকে; যেসব কোম্পানির Exchange Earning ট্রান্সফার হবে সেগুলোর পাশে টিক দিয়ে `Save` করতে হয়।")]),
("Service Pack › Setup › Transfer Exchange Earning Percentage Setup",[
 ("152009","`Service Pack › Setup › Transfer Exchange Earning Percentage Setup` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152014","`Transfer Exchange Earning Percentage Setup`-এ ক্লিক করলে \"Setup for exchange earning transfer\" উইন্ডো খুলে যায়, যেখানে Corresponding Company ও Transfer (শতাংশ, যেমন 99.00 বা 0.00) কলামে প্রতিটি কোম্পানির জন্য কত শতাংশ Exchange Earning ট্রান্সফার হবে তা লিখে `Save` করতে হয়।")]),
("Service Pack › Setup › Company",[
 ("152019","`Service Pack › Setup › Company` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152024","`Company`-তে ক্লিক করলে \"List of existing companies\" উইন্ডো খুলে যায়, যেখানে Name কলামে বিদ্যমান কোম্পানির তালিকা (যেমন Agrani Bank Ltd, Bank Al Habib) ও Total সংখ্যা (52) দেখা যায়; ডান পাশে `Add`, `Edit`, `Delete` ও `Close` বাটন আছে।")]),
("Service Pack › Setup › Remitter",[
 ("152045","`Service Pack › Setup › Remitter`-এ ক্লিক করলে \"List of existing remitters\" উইন্ডো খুলে যায়, যেখানে Code, Full Name, Address ও Telephone No কলামে রেমিটারদের তালিকা এবং Total (16) দেখা যায়; `Add`, `Edit`, `Delete` ও `Close` বাটন আছে।")]),
("Service Pack › Setup › Beneficiary",[
 ("152051","`Service Pack › Setup › Beneficiary` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152100","`Beneficiary`-তে ক্লিক করলে \"List of existing beneficiaries\" উইন্ডো খুলে যায়, যেখানে Exchange ID ও Name, Remitter ID দিয়ে `Search Client` করে নির্বাচিত রেমিটারের বেনিফিশিয়ারিদের Name, Payee, Payee mode ও Beneficiary detail দেখা যায়; `Add`, `Edit`, `Delete` ও `Close` বাটন আছে।")]),
("Service Pack › Setup › Otp Scheme",[
 ("152120","`Service Pack › Setup › Otp Scheme` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152127","`Otp Scheme`-এ ক্লিক করলে \"Otp Scheme\" উইন্ডো খুলে যায়, যেখানে OTP পাঠানোর জন্য Email Addresses (semicolon (;) দিয়ে আলাদা) লিখে `Encrypt` করলে Otp Scheme ঘরে এনক্রিপ্টেড মান তৈরি হয়; নিচে `View` দিয়ে সংরক্ষিত ইমেইল ঠিকানা দেখা যায় এবং `Save` ও `Close` বাটন আছে।")]),
("Service Pack › Setup › Otp Validation",[
 ("152135","`Service Pack › Setup › Otp Validation` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152140","`Otp Validation`-এ ক্লিক করলে \"Otp Validation\" উইন্ডো খুলে যায়, যেখানে `Generate Otp and Send Mail` বাটনে ক্লিক করে OTP পাঠাতে হয়, তারপর Otp (6 Digits) ঘরে ৬ সংখ্যার কোড লিখে `Validate` করতে হয়; সফল হলে `Process Now` বাটন সক্রিয় হয়।")]),
("Service Pack › Transaction › Send Remittance",[
 ("152149","`Service Pack › Transaction`-এ মাউস হোভার করলে Send Remittance সাব-মেনু দেখা যায়।"),
 ("152157","`Send Remittance`-এ ক্লিক করলে \"TT Issuance\" উইন্ডো খুলে যায়। বাম পাশে By exchange বা By company নির্বাচন করে `Load` করলে Outstanding charges to transfer (Description, Date, Amount (EUR), Amount (CFC)) দেখা যায়; ডান পাশে Exchange ID, Transaction Date, Remitter (`Search Client`), Fiscal code, Document type/no, Beneficiary, Company, Branch, Mode of Receive, Purpose of issue ও Amount detail (Remittance Amount, Exchange Rate, Beneficiary Amount, Commission) পূরণ করে `Save` করতে হয়; `Draft Copy` ও `Close` বাটনও আছে।")]),
("Service Pack › Reports › Company wise Ledger",[
 ("152208","`Service Pack › Reports`-এ মাউস হোভার করলে সাব-মেনুগুলো দেখা যায় — Company wise Ledger, Complete Company wise Ledger, Exchange Earning Detail, Exchange Earning Ledger, Transfer Ledger: Summary, Remittance Information, Remittance Flow Statement, Summary Report, Graphical Report, Output Data ও Customized Report।"),
 ("152214","`Company wise Ledger`-এ ক্লিক করলে \"Transaction Ledger\" উইন্ডো খুলে যায়, যেখানে Company (যেমন Agrani Bank Ltd) ও Date range বেছে `Preview` বা `Print` করা যায়।"),
 ("152220","`Preview`-তে ক্লিক করলে \"Company Wise Ledger\" রিপোর্ট দেখা যায়, যেখানে Tran Date, Description, Debit EUR, Credit EUR, Debit CFC, Credit CFC এবং Debit/Credit Balance (EUR ও CFC) কলাম এবং Balance B/F ও Closing balance থাকে।")]),
("Service Pack › Reports › Complete Company wise Ledger",[
 ("152229","`Service Pack › Reports › Complete Company wise Ledger` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152234","`Complete Company wise Ledger`-এ ক্লিক করলে \"Complete Transaction Ledger\" উইন্ডো খুলে যায়, যেখানে Company ও Date range বেছে `Preview` বা `Print` করা যায়।"),
 ("152239","`Preview`-তে ক্লিক করলে \"Complete company ledger\" রিপোর্ট দেখা যায়, যেখানে Value date, Tran date, Description, Benef Amount, Ex-rate, Debit/Credit (EUR, BDT/CFC) ও Balance কলামসহ কোম্পানির পূর্ণ খতিয়ান থাকে।")]),
("Service Pack › Reports › Exchange Earning Detail",[
 ("152247","`Service Pack › Reports › Exchange Earning Detail` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152253","`Exchange Earning Detail`-এ ক্লিক করলে \"Exchange Earning Detail\" উইন্ডো খুলে যায়, যেখানে Exchange ID, Company ID, Exported date বা Issued date এবং Date range দিয়ে `Refresh` করলে Exported date, Issue date, Subcompany, Order No, TT Amount, Benef Amount, ED Rate, PD Rate, CF Rate, CF Amount, Exchange EE, EE Amount ও Total EE কলামে তথ্য দেখা যায়; `Export` দিয়ে ফাইল আকারে নেওয়া যায়।")]),
("Service Pack › Reports › Exchange Earning Ledger",[
 ("152300","`Service Pack › Reports › Exchange Earning Ledger` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে। (এই মেনুতে ক্লিক করার পরের উইন্ডোর Screenshot পাওয়া যায়নি।)")]),
("Service Pack › Reports › Transfer Ledger Summary",[
 ("152310","`Service Pack › Reports › Transfer Ledger: Summary` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152316","`Transfer Ledger: Summary`-তে ক্লিক করলে \"Transfer Ledger\" উইন্ডো খুলে যায়, যেখানে Transfer Ledger of Beneficiary Ledger বা Summary Transfer অপশন, Exchange ID, Remitter ID (`Search Client`), Beneficiary ও Date range বেছে `Preview` বা `Print` করা যায়।")]),
("Service Pack › Reports › Remittance Information",[
 ("152401","`Service Pack › Reports › Remittance Information` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152407","`Remittance Information`-এ ক্লিক করলে \"Remittance Information\" উইন্ডো খুলে যায়, যেখানে Exchange ID, Exclude Cancellation, Remitter (`Search Client`), Telephone No, Date Range ও Preview Options (Service Pack Only বা All Remittance) থাকে; বাম পাশে List of Remittances এবং ডান পাশে নির্বাচিত রেমিট্যান্সের Status (Issue Date, Franchise Name, Beneficiary Name/Phone/Currency/Amount/Account No/Bank/Branch, Drawn on Bank/Branch, Payment Date, Issued By, Refunded By/Time) দেখা যায়; `Preview`, `Print`, `Re-print Remittance` ও `Close` বাটন আছে।")]),
("Service Pack › Reports › Remittance Flow Statement",[
 ("152415","`Service Pack › Reports › Remittance Flow Statement` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152420","`Remittance Flow Statement`-এ ক্লিক করলে \"Remittance flow statement\" উইন্ডো খুলে যায়, যেখানে Show report by (Issue date বা Export date), Date range এবং রিপোর্টের ধরন — City wise, Total flow (internal payee company অনুযায়ী), Flow statement by Country, Subcompany, Company বা Agency — বেছে নিয়ে Exclude cancellation ও Number of digit after decimal নির্ধারণ করে `Preview` বা `Print` করা যায়।")]),
("Service Pack › Reports › Summary Report",[
 ("152429","`Service Pack › Reports › Summary Report` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152440","`Summary Report`-এ ক্লিক করলে \"Summary report\" উইন্ডো খুলে যায়, যেখানে TT type (TT issue, TT payment, Cancellation only), Date filter (Issue date / Export date), Date range, Exchange wise এবং Agency, Country, Payment mode, Company, Subcompany ও Currency wise ফিল্টার এবং TT amount range বেছে `Refresh` করতে হয়; `Preview`, `Print`, `Export` ও `Close` বাটন আছে।")]),
("Service Pack › Reports › Graphical Report",[
 ("152454","`Service Pack › Reports › Graphical Report` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152517","`Graphical Report`-এ ক্লিক করলে \"Customised report\" উইন্ডো খুলে যায়, যেখানে Exchange ID, Date range (Exported / Issued) দিয়ে `Refresh` করে Choose fields তালিকা থেকে ফিল্ড টেনে Report Filter, Column Labels, Row Labels ও Values এলাকায় রাখতে হয়; ডান পাশে Binding options, Generated series from (Columns/Rows) ও Generated series type (Bar, Line, Area) বেছে চার্ট তৈরি হয়; `Print Settings`, `Preview`, `Print`, `Export` ও `Close` বাটন আছে।")]),
("Service Pack › Reports › Output Data",[
 ("152525","`Service Pack › Reports › Output Data` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152532","`Output Data`-তে ক্লিক করলে \"Output data\" উইন্ডো খুলে যায়, যেখানে TT type (Regular, Payment, Exchange, Svc), Cancellation only, Date filter, Date range, Exchange wise এবং Agency, Country, Currency, Company ও Subcompany wise ফিল্টার ও TT amount range বেছে Select Output file নির্বাচন করে `Refresh` ও `Export` করা যায়।")]),
("Service Pack › Reports › Customized Report",[
 ("152543","`Service Pack › Reports › Customized Report` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152548","`Customized Report`-এ ক্লিক করলে \"Report Customiser\" উইন্ডো খুলে যায়, যেখানে Select Report (New Report), Based on (TT issue), Date of (Issued Date) ও তারিখ, Mode of Receive, Payment Mode, Country, Currency, Remittance no, Order no, Value filter, Subcompany ID, Exchange ID, Agency ID ও Exclude অপশন (CXL Apld, CXL Auth, CXL Rfnd, Exported, Hold) বেছে Available Fields থেকে `>>` দিয়ে Selected Fields-এ ফিল্ড যোগ করতে হয়; `Load now`, `Export to Excel` ও `Close` বাটন আছে।")]),
("Management Reports › Yearly TT",[
 ("152557","`Management Reports`-এ ক্লিক করলে Yearly TT ও Yearly TT Issue সাব-মেনু দেখা যায়; এখানে Yearly TT হাইলাইট করা।"),
 ("152604","`Yearly TT`-তে ক্লিক করলে \"Dynamic report: Yearly TT\" উইন্ডো খুলে যায়, যেখানে উপরে Legend সহ চার্ট এলাকা, মাঝে Drag filter/column/data items এলাকা এবং ডান পাশে Binding options, Generated series from ও Generated series type (Bar, Line, Area) থাকে; `Print Settings`, `Preview`, `Print`, `Export` ও `Close` বাটন আছে।")]),
("Management Reports › Yearly TT Issue",[
 ("152612","`Management Reports › Yearly TT Issue` মেনুটি হাইলাইট করা অবস্থায় দেখা যাচ্ছে।"),
 ("152617","`Yearly TT Issue`-তে ক্লিক করলে \"Dynamic report: Yearly TT Issue\" উইন্ডো খুলে যায়, যেখানে # TT ও Year ফিল্ড দিয়ে বছরভিত্তিক TT Issue-এর ডায়নামিক রিপোর্ট ও চার্ট তৈরি করা যায়; Binding options ও Generated series type বেছে `Preview`, `Print` বা `Export` করা যায়।")]),
("Windows › Cascade",[("152640","`Windows` মেনুতে Cascade, Tile Horizontal, Tile Vertical, Arrange Icons ও Close all অপশন থাকে; `Cascade` বেছে নিলে খোলা উইন্ডোগুলো একটির উপর আরেকটি ধাপে ধাপে সাজানো হয়।")]),
("Windows › Tile Horizontal",[("152652","`Windows › Tile Horizontal` বেছে নিলে খোলা উইন্ডোগুলো পাশাপাশি অনুভূমিকভাবে (উপর-নিচে) সাজানো হয়।")]),
("Windows › Tile Vertical",[("152701","`Windows › Tile Vertical` বেছে নিলে খোলা উইন্ডোগুলো উল্লম্বভাবে (পাশাপাশি কলামে) সাজানো হয়।")]),
("Windows › Arrange Icons",[("152709","`Windows › Arrange Icons` বেছে নিলে ছোট (minimize) করা উইন্ডোর আইকনগুলো নিচে সারিবদ্ধভাবে সাজানো হয়।")]),
("Windows › Close all",[("152715","`Windows › Close all` বেছে নিলে খোলা সব উইন্ডো একসাথে বন্ধ হয়ে যায়।")]),
]
L2=[("Central Admin › Daily Tasks › Before Branch Start › Exchange currency rate setup",[
 ("2026-10-28 121035","`Central Admin › Daily Tasks › Before Branch Start`-এ মাউস হোভার করলে Exchange currency rate setup, Base Rate Setup, Exchange wise Dealing Rate, Sub-company wise Dealing Rate, Minimum and Maximum Rate, Display Dealing Rate, Payment Service Information, Export Rate, Public Currency Rates ও Country Wise Export Rate সাব-মেনু দেখা যায়।"),
 ("2026-10-29 123413","`Exchange currency rate setup`-এ ক্লিক করলে Exchange-এর local currency rate পরিবর্তনের উইন্ডো খুলে যায়, যেখানে তারিখ (22 Nov 2024), অবস্থা (Not Saved) ও মুদ্রা (EUR) নির্বাচন করে Exchange, Currency ও Rate কলামে প্রতিটি Exchange কোম্পানির রেট লিখে `Save` করতে হয়।")]),
("Central Admin › Daily Tasks › Sending of TT",[
 ("2026-10-27 122016","`Central Admin › Daily Tasks › Sending of TT`-এ মাউস হোভার করলে সাব-মেনুগুলো দেখা যায় — Change Bank Branch, Authorise TT, Unauthorise TT, Hold/Unhold TT (Regular), Unhold TT (Black Listed), Unhold Franchise TT, Sending of TT, Undo Send TT, Resend TT, Update Status From WS, KASSI Api Integration, BELMONEY Api Integration, Process Third Party GL Tran, Upload Exchange TT, Update Exchange TT Status ও Exported file summary।")])]
out=[]
import os
for path,items in L+L2:
  for f,d in items:
    fn=f if f.startswith('2026') else '2026-11-05 '+f
    out.append(dict(doc='late',src='Screenshot '+fn+'.png',desc=d,path=path,how='late'))
json.dump(out,open('late.json','w'),ensure_ascii=False,indent=0)
P={r['path'] for r in json.load(open('menu.json'))}
bad=[o['path'] for o in out if o['path'] not in P]; print(len(out),'bad:',set(bad))
