"use strict";
function startApp(D){
/* ================= Data ================= */
const P = D.pages, ORDER = D.order;
const $ = s => document.querySelector(s), main = $("#main");
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
// mini markdown: `ui text` -> code, **bold**
const md = s => esc(s).replace(/`([^`]+)`/g, '<code class="ui term">$1</code>').replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
const MODS = ORDER.filter(i => P[i].k === "module");

/* ================= Storage (best-effort) ================= */
function store(k, v){ try{ if(v === undefined) return JSON.parse(localStorage.getItem(k)); localStorage.setItem(k, JSON.stringify(v)); }catch(e){ return null; } }

/* ================= Language ================= */
let LANG = store("nec_lang") === "en" ? "en" : "bn";
const isEn = () => LANG === "en";
const T = (bn, en) => isEn() ? en : bn;             // inline pick
const UI = {
  brand:["NEC EFT ব্যবহার নির্দেশিকা","NEC EFT User Manual"], searchBtn:["Documentation খুঁজুন…","Search documentation…"],
  lifecycle:["TT-এর জীবনচক্র","TT Lifecycle"], rules:["Business Rules ও নিয়ন্ত্রণ","Business Rules & Controls"], glossary:["শব্দকোষ (Glossary)","Glossary"],
  recent:["সম্প্রতি দেখা","Recently viewed"], allMods:["সব Module","All modules"], onPage:["এই পাতায়","On this page"],
  print:["এই পাতা প্রিন্ট","Print this page"], top:["উপরে যান","Back to top"], kNav:["নির্বাচন","select"], kOpen:["খুলুন","open"], kEsc:["বন্ধ","close"],
  fit:["মাপমতো","Fit"], close:["বন্ধ","Close"], clear:["মুছুন","Clear"], collapse:["সব বন্ধ","Collapse all"], noMatch:["কোনো মেনু মেলেনি","No matching menu"], filterPh:["মেনু খুঁজুন…","Filter menu…"], noRecent:["এখনো কোনো পাতা দেখা হয়নি","Nothing viewed yet"],
  sPh:["Feature, Menu বা যেকোনো শব্দ খুঁজুন","Search features, menus or any word"],
  sHelp:["Feature-এর নাম (English বা বাংলা), Menu Path, Menu Code, Requirement ID (যেমন BR-004) বা বর্ণনার যেকোনো শব্দ লিখুন।","Type a feature name (English or Bangla), menu path, menu code, requirement ID (e.g. BR-004) or any word from the descriptions."],
  sNone:["কোনো ফলাফল পাওয়া যায়নি। অন্য শব্দ দিয়ে চেষ্টা করুন।","No results. Try another word."], sCount:["টি ফলাফল"," results"],
  copied:["কপি হয়েছে: ","Copied: "], fig:["চিত্র","Figure"], guide:["নির্দেশিকা","Guide"],
};
const U = k => UI[k][isEn() ? 1 : 0];
const name = p => isEn() ? p.en : p.bn;              // page title in current language
const nameSub = p => isEn() ? "" : p.en;           // the other language, shown under the title
function num(n){ return isEn() ? String(n) : String(n).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]); }

const MOD_DESC = {
  "File":["Login, Logout, Password পরিবর্তন, ডকুমেন্ট স্ক্যান, ছুটির ক্যালেন্ডার ও প্রস্থান।","Login, logout, password change, document scanning, holiday calendar and exit."],
  "Administrator":["সিস্টেমের মূল সেটআপ: ইউজার, দেশ-মুদ্রা, ব্যাংক, চার্জ, লিমিট, ফাইল ফরম্যাট ও Web Service।","Core system setup: users, countries and currencies, banks, charges, limits, file formats and web services."],
  "Central Admin":["Head Office-এর দৈনন্দিন কাজ: রেট, TT অনুমোদন ও পাঠানো, দিনশেষ/মাসশেষ, অনুসন্ধান ও রিপোর্ট।","Head Office daily work: rates, TT authorisation and sending, end of day/month, queries and reports."],
  "General Ledger":["হিসাব: ভাউচার, Opening Balance, খতিয়ান, Trial Balance ও আর্থিক রিপোর্ট।","Accounting: vouchers, opening balances, ledgers, trial balance and financial reports."],
  "Exchange":["Exchange কোম্পানি পর্যায়: ফ্রাঞ্চাইজি, চার্জ, লিমিট, TT নিয়ন্ত্রণ, দিনশেষ ও নিজস্ব হিসাব।","Exchange-company level: franchises, charges, limits, TT control, end of day and its own accounts."],
  "Agency":["Agent/Teller-এর কাজ: Remitter, Beneficiary, TT Issue ও Payment, নগদ ব্যবস্থাপনা ও রিপোর্ট।","Agent/Teller work: Remitters, Beneficiaries, TT Issue and Payment, cash handling and reports."],
  "Service Pack":["সার্ভিস প্যাক সেটআপ, রেমিট্যান্স পাঠানো ও সংশ্লিষ্ট রিপোর্ট।","Service Pack setup, sending remittances and related reports."],
  "Management Reports":["বাৎসরিক TT ও TT Issue-এর ডায়নামিক রিপোর্ট।","Dynamic yearly TT and TT Issue reports."],
  "Windows":["খোলা উইন্ডোগুলো সাজানো বা একসাথে বন্ধ করা।","Arrange open windows or close them all at once."]};
const modDesc = m => (MOD_DESC[m] || ["",""])[isEn() ? 1 : 0];
const MOD_ICON = {"File":"📁","Administrator":"🛠️","Central Admin":"🏢","General Ledger":"📒","Exchange":"💱","Agency":"🏪","Service Pack":"🧩","Management Reports":"📊","Windows":"🪟"};
// per-page field pickers
const F = {
  pu: p => isEn() ? p.pue : p.pu, ro: p => isEn() ? p.roe : p.ro, st: p => isEn() ? p.ste : p.st, rs: p => isEn() ? p.rse : p.rs,
  cap: s => isEn() ? s.ce : s.c, nt: n => isEn() ? n.te : n.t, pq: x => isEn() ? x.qe : x.q, pa: x => isEn() ? x.ae : x.a,
};


/* ================= Line icons (inline SVG, offline) ================= */
const ICO = {
  home:'<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>',
  layers:'<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 13 9 5 9-5"/>',
  cycle:'<path d="M20 12a8 8 0 0 1-14 5.3"/><path d="M4 12A8 8 0 0 1 18 6.7"/><path d="M18 3v4h-4"/><path d="M6 21v-4h4"/>',
  shield:'<path d="M12 3 4 6v6c0 4.5 3.4 8 8 9 4.6-1 8-4.5 8-9V6l-8-3z"/><path d="m9 12 2 2 4-4"/>',
  book:'<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5z"/><path d="M4 19a2 2 0 0 1 2-2h13"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  chev:'<path d="m9 6 6 6-6 6"/>',
  "File":'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/>',
  "Administrator":'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  "Central Admin":'<path d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/><path d="M16 9h2a2 2 0 0 1 2 2v10"/><path d="M8 7h4M8 11h4M8 15h4"/><path d="M2 21h20"/>',
  "General Ledger":'<path d="M5 3h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5z"/><path d="M9 3v18"/><path d="M12 8h4M12 12h4"/>',
  "Exchange":'<path d="M7 7h13l-4-4"/><path d="M17 17H4l4 4"/>',
  "Agency":'<path d="M4 10v10h16V10"/><path d="M3 4h18l-1.5 6a2.5 2.5 0 0 1-4.5 0 2.5 2.5 0 0 1-5 0 2.5 2.5 0 0 1-5 0L3 4z"/><path d="M10 20v-5h4v5"/>',
  "Service Pack":'<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="m4 7.5 8 4.5 8-4.5"/><path d="M12 12v9"/>',
  "Management Reports":'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  "Windows":'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>',
};
const svg = k => `<svg viewBox="0 0 24 24">${ICO[k]||ICO.layers}</svg>`;

/* ================= Images: base64 lives in <script type=text/plain id=iN>; decoded on demand ================= */
const imgCache = {};
const io = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ const cv = e.target; BOOT.paint(cv, cv.dataset.img); cv.removeAttribute("data-img"); io.unobserve(cv); } }), {rootMargin:"600px 0px"});
// screenshots of a page after editor changes (replaced / removed images)
const shots = p => p.sh.filter(s => !BOOT.isDeleted(p.id, s.i)).map(s => ({...s, i: BOOT.mapImg(p.id, s.i), o: s.i}));

/* ================= Sidebar tree ================= */
function nodeHTML(id, depth){
  const p = P[id], has = p.kids.length > 0;
  const tw = has ? `<span class="tw" aria-hidden="true">${svg("chev")}</span>` : "";
  if(depth === 0){
    const lbl = `<span class="lbl">${esc(p.en)}${isEn() ? "" : `<small>${esc(p.bn)}</small>`}</span>`;
    return `<div class="node mod" data-id="${id}"><button class="nl" data-go="${id}" data-tw="1" title="${esc(isEn()?p.p:p.bn)}"><span class="ic">${svg(p.en)}</span>${lbl}<span class="cnt">${countScreens(id)}</span>${tw}</button><div class="kids">${p.kids.map(k=>nodeHTML(k,1)).join("")}</div></div>`;
  }
  return `<div class="node" data-id="${id}"><button class="nl" data-go="${id}" ${has?'data-tw="1"':""} title="${esc(isEn()?p.p:p.bn)}"><span class="lbl">${esc(p.en)}</span>${tw}</button>${has?`<div class="kids">${p.kids.map(k=>nodeHTML(k,depth+1)).join("")}</div>`:""}</div>`;
}
function buildTree(){ $("#tree").innerHTML = MODS.map(m => nodeHTML(m, 0)).join(""); if(navQ) filterNav(navQ); else if(current && P[current]) openTo(current);
  document.querySelectorAll("#tree .nl").forEach(a => a.classList.toggle("active", a.dataset.go === current)); }

/* ---- sidebar menu filter: keeps matches and their parents, auto-expands ---- */
let navQ = "";
function filterNav(q){
  navQ = q.trim().toLowerCase();
  const sb = $("#sidebar"); sb.classList.toggle("filtering", !!navQ); $(".sb-search").classList.toggle("has", !!navQ);
  const nodes = [...document.querySelectorAll("#tree .node")];
  nodes.forEach(n => { const l = n.querySelector(":scope>.nl .lbl"); if(l.dataset.raw === undefined) l.dataset.raw = l.innerHTML; l.innerHTML = l.dataset.raw; n.classList.remove("hide"); });
  if(!navQ){ nodes.forEach(n => n.classList.remove("open")); if(P[current]) openTo(current); $("#navEmpty").style.display = "none"; return; }
  const hit = id => { const p = P[id]; return (p.en + " " + p.bn + " " + p.code).toLowerCase().includes(navQ); };
  let any = 0;
  const walk = n => { const id = n.dataset.id, kids = [...n.querySelectorAll(":scope>.kids>.node")];
    let sub = false; kids.forEach(k => { if(walk(k)) sub = true; });
    const me = hit(id), show = me || sub;
    n.classList.toggle("hide", !show); n.classList.toggle("open", sub);
    if(me){ any++; const l = n.querySelector(":scope>.nl .lbl"); l.innerHTML = l.innerHTML.replace(new RegExp("(" + reEsc(esc(navQ)) + ")", "gi"), '<mark class="f">$1</mark>'); }
    return show; };
  document.querySelectorAll("#tree>.node").forEach(walk);
  $("#navEmpty").style.display = any ? "none" : "block";
}

function openTo(id){
  document.querySelectorAll("#tree .node").forEach(n => n.classList.remove("open"));
  let cur = id;
  while(cur){ const n = document.querySelector(`#tree .node[data-id="${cur}"]`); if(n) n.classList.add("open"); cur = P[cur] ? P[cur].parent : null; }
  const n = document.querySelector(`#tree .node[data-id="${id}"]`); if(n && !P[id].kids.length) n.classList.remove("open");
}

/* ================= Rendering helpers ================= */
const H2 = (n, id, t) => `<h2 id="${id}"><span class="n">${n}</span>${t}</h2>`;
function crumb(p){
  const chain = []; let c = p.parent; while(c){ chain.unshift(c); c = P[c].parent; }
  return `<div class="crumb"><span><a href="#home" data-go="home">Home</a></span>${chain.map(i=>`<span><a href="#${i}" data-go="${i}">${esc(P[i].en)}</a></span>`).join("")}<span>${esc(p.en)}</span></div>`;
}
function shotHTML(s, n, p){
  const cap = `${p.en} — ${U("fig")} ${num(n)}`;
  return `<figure class="shot"><div class="shot-frame" data-zoom="${s.i}" data-cap="${esc(cap)}"><span class="shot-no">${U("fig")} ${num(n)}</span><canvas class="shot-img" data-img="${s.i}" data-orig="${s.o}" role="img" aria-label="${esc(cap)}" width="16" height="9"></canvas></div>
  <figcaption>${md(F.cap(s)||"")}${s.l?`<span class="tag" title="${T("এই বর্ণনা ৫ নভেম্বরের Screenshot দেখে যুক্ত করা হয়েছে","This description was written from the 5 November screenshots")}">${T("Screenshot থেকে বর্ণনা","Described from screenshot")}</span>`:""}</figcaption></figure>`;
}
function mockHTML(p){
  return `<figure class="shot"><div class="shot-frame" style="cursor:default"><span class="badge-sample">${T("নমুনা চিত্র – প্রকৃত System Screenshot নয়","Sample illustration – not a real system screenshot")}</span>
  <div class="mock" aria-hidden="true"><div class="mock-title"><span>${esc(p.en)}</span><span>_ □ ✕</span></div><div class="mock-path">${esc(p.p)}</div>
  <div class="mock-body"><div class="mrow"><i></i><u></u></div><div class="mrow"><i></i><u></u></div><div class="mrow"><i></i><u></u></div><div class="mrow"><i></i><u></u></div><div class="mgrid"></div><div class="mbtns"><span>Close</span></div></div></div></div>
  <figcaption>${T("এই Screen-এর প্রকৃত Screenshot Source ফোল্ডারে পাওয়া যায়নি। উপরের ছবিটি শুধু Menu Path ও উইন্ডোর সাধারণ ধারণা দেখানোর জন্য — এর ঘর বা বাটনগুলো প্রকৃত Screen-এর সাথে নাও মিলতে পারে।",
  "No real screenshot of this screen was found in the source folders. The picture above only shows the menu path and a general idea of the window — its fields and buttons may not match the real screen.")}</figcaption></figure>`;
}
function linkList(ids){ return `<div class="links">${ids.map(i=>`<a href="#${i}" data-go="${i}">${esc(P[i].en)}${isEn()?"":` <small style="opacity:.7">· ${esc(P[i].bn)}</small>`}</a>`).join("")}</div>`; }
const roleCards = list => `<div class="roles">${(list||[]).map(r=>`<div class="card"><b>${esc(r[0])}</b><span>${esc(r[1])}</span></div>`).join("")}</div>`;
const stepList = list => `<ol class="steps">${(list||[]).map(s=>`<li><span class="stt">${md(s[0])}</span>${md(s[1])}</li>`).join("")}</ol>`;

/* ================= Feature (screen) page ================= */
function screenPage(p){
  let n = 0, h = crumb(p);
  h += `<h1>${esc(name(p))}${nameSub(p)?`<span class="en">${esc(nameSub(p))}</span>`:""}</h1>`;
  h += `<div class="meta"><span class="chip acc">${MOD_ICON[p.mod]||""} ${esc(p.mod)}</span><span class="chip">Menu Code ${esc(p.code)}</span><span class="chip">${esc(p.p)}</span>${p.sh.length?`<span class="chip">📷 ${num(p.sh.length)} ${T("টি Screenshot","screenshot"+(p.sh.length>1?"s":""))}</span>`:`<span class="chip">📷 ${T("Screenshot নেই","No screenshot")}</span>`}</div>`;
  h += H2(++n,"why",T("এই Feature কেন ব্যবহার করবেন?","Why use this feature?")) + `<p>${md(F.pu(p))}</p>`;
  h += H2(++n,"who",T("কে এই Feature ব্যবহার করবেন?","Who uses this feature?")) + roleCards(F.ro(p))
     + `<p style="margin-top:10px;font-size:14px;color:var(--muted)">${T("মেনুটি দেখা যাবে কিনা তা আপনার User Group-এর অনুমতির উপর নির্ভর করে।","Whether you can see this menu depends on your User Group permissions.")} <span class="src">ADM-002 · ADM-007</span></p>`;
  h += H2(++n,"how",T("কীভাবে ব্যবহার করবেন?","How to use it")) + stepList(F.st(p));
  h += H2(++n,"info",T("প্রয়োজনীয় তথ্য","Required information"));
  const fl = isEn() ? [...new Set(p.fl.map(x => x.replace(/[\u0980-\u09FF]+[^\sA-Za-z]*/g, "").replace(/\s+/g, " ").trim()).filter(x => /[A-Za-z]{2}/.test(x)))] : p.fl;
  h += fl.length ? `<p>${T("এই Screen-এ নিচের ঘর বা তথ্যগুলো দেখা যায় বা পূরণ করতে হয় (Screenshot-এর বর্ণনা থেকে নেওয়া; ক্লিক করলে কপি হবে):","These fields or items appear on this screen or must be filled in (taken from the screenshot descriptions; click to copy):")}</p><div class="fields">${fl.map(f=>`<span class="term">${esc(f)}</span>`).join("")}</div>`
                   : `<p>${T("এই Screen-এর জন্য আলাদা কোনো ঘরের তালিকা Source ডকুমেন্টে উল্লেখ নেই। নিচের Screenshot ও তার বর্ণনা দেখুন।","The source documents do not list separate fields for this screen. See the screenshots and descriptions below.")}</p>`;
  if(p.bt.length) h += `<h3>${T("বাটনসমূহ","Buttons")}</h3><div class="fields">${p.bt.map(b=>`<span class="term">${esc(b)}</span>`).join("")}</div>`;
  h += H2(++n,"shots",T("Screenshot ব্যাখ্যা","Screenshots explained"));
  { const S = shots(p); if(S.length) h += S.map((s,i)=>shotHTML(s,i+1,p)).join("");
  else { h += mockHTML(p); if(p.sim && p.sim.length) h += `<p>${T("একই নামের Screen অন্য Module-এ প্রকৃত Screenshot সহ আছে — তুলনার জন্য দেখুন:","A screen with the same name exists in another module with real screenshots — see it for comparison:")}</p>${linkList(p.sim)}`; } }
  h += H2(++n,"result","Expected Result") + `<ul class="res">${(F.rs(p)||[]).map(r=>`<li>${md(r)}</li>`).join("")}</ul>`;
  h += H2(++n,"notes","Important Notes");
  h += p.no.length ? p.no.map(x=>`<div class="callout ${x.k}">${esc(F.nt(x))} <span class="src">${esc(x.s)}</span></div>`).join("")
                   : `<div class="callout info">${T("এই Screen-এর জন্য Source ডকুমেন্টে আলাদা কোনো Business Rule উল্লেখ নেই।","The source documents state no separate business rule for this screen.")}</div>`;
  h += `<div class="callout info">${T("Screenshot-গুলো টেস্ট পরিবেশ থেকে নেওয়া (System date 22 Nov 2024, Version 3.3.3.3); ছবিতে দেখা তারিখ, নাম ও পরিমাণ শুধু উদাহরণ।","Screenshots come from the test environment (system date 22 Nov 2024, version 3.3.3.3); dates, names and amounts shown are examples only.")}</div>`;
  const G = T("অনুমান","Assumption");
  h += H2(++n,"faq","Common Problems & Solutions") + p.pr.map(x=>`<details class="faq"><summary>${esc(F.pq(x))}${x.g?`<span class="guess">${G}</span>`:""}</summary><div class="ans">${esc(F.pa(x))}${x.s?` <span class="src">${esc(x.s)}</span>`:""}</div>${x.g?`<br><small style="color:var(--muted)">${T("এই সমাধান Source ডকুমেন্টে নেই — সাধারণ অভিজ্ঞতা থেকে দেওয়া।","This solution is not in the source documents — it is general guidance.")}</small>`:""}</details>`).join("");
  if(p.rel && p.rel.length) h += H2(++n,"related","Related Features") + linkList(p.rel);
  h += `<div class="pager">${p.pv?`<a href="#${p.pv}" data-go="${p.pv}"><small>${T("← আগের Feature","← Previous feature")}</small>${esc(P[p.pv].en)}</a>`:"<span></span>"}${p.nx?`<a class="nx" href="#${p.nx}" data-go="${p.nx}"><small>${T("পরের Feature →","Next feature →")}</small>${esc(P[p.nx].en)}</a>`:"<span></span>"}</div>`;
  return h;
}

/* ================= Menu / module overview page ================= */
function menuPage(p){
  let n = 0, h = crumb(p);
  const cnt = p.kids.length;
  h += `<h1>${p.k==="module"?(MOD_ICON[p.en]||"")+" ":""}${esc(name(p))}${nameSub(p)?`<span class="en">${esc(nameSub(p))}</span>`:""}</h1>`;
  h += `<p class="lead">${p.k==="module"?esc(modDesc(p.en)):esc(T(`${p.p} মেনুর অধীনে ${num(cnt)}টি অপশন আছে।`,`The ${p.p} menu has ${cnt} options.`))}</p>`;
  h += `<div class="meta"><span class="chip acc">${esc(p.mod)}</span><span class="chip">Menu Code ${esc(p.code)}</span><span class="chip">${T(num(cnt)+"টি অপশন",cnt+" options")}</span></div>`;
  if(F.ro(p) && F.ro(p).length) h += H2(++n,"who",T("কে ব্যবহার করবেন?","Who uses it?")) + roleCards(F.ro(p));
  if(F.st(p) && F.st(p).length) h += H2(++n,"how",T("কীভাবে এই মেনুতে যাবেন?","How to reach this menu")) + stepList(F.st(p));
  h += H2(++n,"items",T("এই মেনুর অপশনসমূহ","Options in this menu")) + `<div class="grid">${p.kids.map(k=>{const c=P[k];
    const em = c.k==="screen" ? (c.sh.length ? "📷 "+T(num(c.sh.length)+"টি Screenshot", c.sh.length+" screenshot"+(c.sh.length>1?"s":"")) : T("Screenshot নেই","No screenshot")) : T(num(c.kids.length)+"টি অপশন ▸", c.kids.length+" options ▸");
    return `<button class="card mcard" data-go="${k}"><span class="mcode">${esc(c.code)}</span><b>${esc(c.en)}</b>${isEn()?"":`<span>${esc(c.bn)}</span>`}<em>${em}</em></button>`}).join("")}</div>`;
  { const S = shots(p); if(S.length) h += H2(++n,"shots",T("Screenshot ব্যাখ্যা","Screenshots explained")) + S.map((s,i)=>shotHTML(s,i+1,p)).join(""); }
  return h;
}

/* ================= Special pages ================= */
function countScreens(id){ const p=P[id]; if(p.k==="screen") return 1; return p.kids.reduce((a,k)=>a+countScreens(k),0); }
const modId = en => MODS.find(m=>P[m].en===en);
function homePage(){
  const s = D.stats;
  let h = `<div class="hero"><h1>${T("NEC EFT ব্যবহার নির্দেশিকা","NEC EFT User Manual")}<span class="en">${T("Electronic Fund Transfer System — Bangla User Manual","Electronic Fund Transfer System — Bangla & English")}</span></h1>
  <p class="lead">${T("National Exchange Company S.r.l.-এর EFT System-এর প্রতিটি মেনু ও Screen সহজ বাংলায়, প্রকৃত Screenshot সহ ধাপে ধাপে ব্যাখ্যা করা হয়েছে — যাতে কম্পিউটারে নতুন একজন ব্যবহারকারীও নিজে কাজ করতে পারেন।",
   "Every menu and screen of the National Exchange Company S.r.l. EFT System, explained step by step in plain language with real screenshots — so that even a first-time computer user can work on their own.")}</p>
  <div class="stats"><div><b>${num(s.modules)}</b><span>${T("প্রধান মেনু","Main menus")}</span></div><div><b>${num(s.menus)}</b><span>${T("সাব-মেনু","Sub-menus")}</span></div><div><b>${num(s.screens)}</b><span>${T("Screen / Feature","Screens / features")}</span></div><div><b>${num(s.shots)}</b><span>${T("প্রকৃত Screenshot","Real screenshots")}</span></div></div></div>`;
  const card = (mod, ic, tb, te, db, de, eb, ee) => `<button class="card mcard" data-go="${mod}"><b>${ic} ${T(tb,te)}</b><span>${T(db,de)}</span><em>${T(eb,ee)}</em></button>`;
  h += H2(1,"start",T("কোথা থেকে শুরু করবেন?","Where to start")) + `<div class="roles">
   ${card(modId("Agency"),"🏪","আমি Agent / Teller","I am an Agent / Teller","Remitter (যিনি টাকা পাঠান) ও Beneficiary (যিনি টাকা গ্রহণ করেন) যোগ, TT Issue ও TT Payment।","Add Remitters (senders) and Beneficiaries (receivers), TT Issue and TT Payment.","Agency মেনু ▸","Agency menu ▸")}
   ${card(modId("Exchange"),"💱","আমি Exchange ইউজার","I am an Exchange user","ফ্রাঞ্চাইজি ব্যবস্থাপনা, TT নিয়ন্ত্রণ, Hold/Release ও দিনশেষের কাজ।","Franchise management, TT control, hold/release and end-of-day work.","Exchange মেনু ▸","Exchange menu ▸")}
   ${card(modId("Central Admin"),"🏢","আমি Head Office অপারেশন","I work in Head Office operations","রেট নির্ধারণ, TT অনুমোদন ও পাঠানো, দিনশেষ ও রিপোর্ট।","Rates, TT authorisation and sending, end of day and reports.","Central Admin মেনু ▸","Central Admin menu ▸")}
   ${card(modId("Administrator"),"🛠️","আমি System Administrator","I am a System Administrator","ইউজার, রেফারেন্স ডেটা, চার্জ, লিমিট ও Integration সেটআপ।","Users, reference data, charges, limits and integration setup.","Administrator মেনু ▸","Administrator menu ▸")}
   ${card(modId("General Ledger"),"📒","আমি হিসাব বিভাগে","I work in Accounts","ভাউচার, General Ledger (GL), খতিয়ান ও আর্থিক রিপোর্ট।","Vouchers, General Ledger (GL), ledgers and financial reports.","General Ledger মেনু ▸","General Ledger menu ▸")}
   ${card("lifecycle","🔄","পুরো প্রক্রিয়া বুঝতে চাই","I want the big picture","একটি TT কীভাবে Agency থেকে প্রাপক পর্যন্ত পৌঁছায়।","How a TT travels from the Agency to the beneficiary.","TT-এর জীবনচক্র ▸","TT Lifecycle ▸")}</div>`;
  h += H2(2,"mods",T("সব Module (System-এর প্রধান মেনু)","All modules (main system menus)")) + `<div class="grid">${MODS.map(m=>{const p=P[m];return `<button class="card mcard" data-go="${m}"><span class="mcode">${esc(p.code)}</span><b>${MOD_ICON[p.en]||""} ${esc(p.en)}${isEn()?"":" · "+esc(p.bn)}</b><span>${esc(modDesc(p.en))}</span><em>${T(num(countScreens(m))+"টি Screen ▸",countScreens(m)+" screens ▸")}</em></button>`}).join("")}</div>`;
  h += H2(3,"read",T("এই নির্দেশিকা কীভাবে পড়বেন","How to read this manual")) + `<p>${T(
   `বাম পাশের মেনু System-এর আসল মেনুর মতোই সাজানো — যেমন <code class="ui">Agency › Remittance › TT Issue</code>। প্রতিটি Feature পাতায় একই ক্রমে তথ্য থাকে: কেন ব্যবহার করবেন, কে ব্যবহার করবেন, কীভাবে করবেন, প্রয়োজনীয় তথ্য, Screenshot ব্যাখ্যা, Expected Result, Important Notes এবং Common Problems & Solutions। কোনো কিছু খুঁজতে উপরের Search বাক্সে ক্লিক করুন বা কীবোর্ডে <code class="ui">Ctrl + K</code> অথবা <code class="ui">/</code> চাপুন। উপরের <b>বাংলা / English</b> বাটন দিয়ে ভাষা বদলানো যায়।`,
   `The left-hand menu follows the system's real menus — e.g. <code class="ui">Agency › Remittance › TT Issue</code>. Every feature page has the same order: why to use it, who uses it, how to use it, required information, screenshots explained, expected result, important notes and common problems & solutions. To find anything, click the search box at the top or press <code class="ui">Ctrl + K</code> or <code class="ui">/</code>. Use the <b>বাংলা / English</b> button at the top to switch language.`)}</p>
  <div class="callout rule">${T(`প্রতিটি নিয়মের পাশে ছোট অক্ষরে উৎস দেওয়া আছে (যেমন <span class="src">BR-004 · AGY-009</span>) — এগুলো “NEC EFT Business & High-Level Requirements v1.0” ডকুমেন্টের Requirement ID। Source-এ নেই এমন পরামর্শ <span class="guess">অনুমান</span> চিহ্ন দিয়ে আলাদা করা।`,
   `Each rule shows its source in small type (e.g. <span class="src">BR-004 · AGY-009</span>) — these are requirement IDs from “NEC EFT Business & High-Level Requirements v1.0”. Advice not found in the sources is marked <span class="guess">Assumption</span>.`)}</div>`;
  return h;
}
function overviewPage(){
  const s = D.stats;
  let h = `<div class="crumb"><span><a href="#home" data-go="home">Home</a></span><span>Documentation Overview</span></div><h1>Documentation Overview<span class="en">${T("উৎস, কাঠামো ও Coverage","Sources, structure and coverage")}</span></h1>`;
  h += H2(1,"src",T("এই নির্দেশিকা কোন উৎস থেকে তৈরি","Sources used")) + `<table><tr><th>${T("উৎস","Source")}</th><th>${T("যা নেওয়া হয়েছে","What was taken")}</th></tr>
   <tr><td>${T("User-manual ফোল্ডারের ১০টি “Features Extract and Explanation” ডকুমেন্ট","The 10 “Features Extract and Explanation” documents in the User-manual folder")}</td><td>${T("প্রতিটি Screen-এর প্রকৃত Screenshot ও বাংলা বর্ণনা","Real screenshots and Bangla descriptions of each screen (translated for the English version)")}</td></tr>
   <tr><td>National Exchange Menu Map.xlsx</td><td>${T(`সম্পূর্ণ মেনু কাঠামো, Menu Code ও Full Path (${num(s.screens)}টি Screen)`,`Full menu structure, menu codes and full paths (${s.screens} screens)`)}</td></tr>
   <tr><td>${T("Screenshort ফোল্ডার (১,৩৪৪টি PNG) ও NEC_EFT_Screens_Knowledge.md","Screenshort folder (1,344 PNGs) and NEC_EFT_Screens_Knowledge.md")}</td><td>${T("ডকুমেন্টে না থাকা Screen-এর Screenshot (৫ নভেম্বরের ছবি) ও মেনুর ধারণা","Screenshots of screens missing from the documents (5 November images) and menu background")}</td></tr>
   <tr><td>NEC EFT Business & High-Level Requirements v1.0</td><td>${T("Business Rules ও Requirement ID (Important Notes-এ উল্লেখিত)","Business rules and requirement IDs (cited in Important Notes)")}</td></tr></table>`;
  h += H2(2,"cov","Coverage") + `<p>${T(`মোট <b>${num(s.screens)}</b>টি Screen-এর মধ্যে <b>${num(s.withshot)}</b>টির প্রকৃত Screenshot যুক্ত আছে। বাকি <b>${num(s.noshot.length)}</b>টির Screenshot Source-এ পাওয়া যায়নি; সেগুলোতে “নমুনা চিত্র – প্রকৃত System Screenshot নয়” চিহ্নিত ধারণাচিত্র দেওয়া হয়েছে, Documentation বাদ দেওয়া হয়নি।`,
   `Of <b>${s.screens}</b> screens, <b>${s.withshot}</b> have real screenshots. For the remaining <b>${s.noshot.length}</b> no screenshot was found in the sources; they show an illustration marked “Sample illustration – not a real system screenshot”, and their documentation is kept.`)}</p>`;
  h += `<h3>${T("Screenshot নেই এমন Screen","Screens without a screenshot")}</h3>${linkList(s.noshot)}`;
  h += H2(3,"tree",T("Module অনুযায়ী বিভাজন","Breakdown by module")) + `<table><tr><th>Module</th><th>Menu Code</th><th>Screen</th><th>${T("যার জন্য","For")}</th></tr>${MODS.map(m=>`<tr><td><a href="#${m}" data-go="${m}">${esc(P[m].en)}</a>${isEn()?"":" · "+esc(P[m].bn)}</td><td>${esc(P[m].code)}</td><td>${num(countScreens(m))}</td><td>${esc((F.ro(P[m])||[]).map(r=>r[0]).join(", "))}</td></tr>`).join("")}</table>`;
  return h;
}
const GLOSS = [
 ["Remitter","যিনি টাকা পাঠান (প্রেরক)।","The person who sends money."],["Beneficiary","যিনি টাকা গ্রহণ করেন (প্রাপক)।","The person who receives money."],
 ["Agent / Franchise","যিনি গ্রাহকের হয়ে লেনদেন পরিচালনা করেন; System-এ এজেন্সি আউটলেট “Franchise” নামে পরিচিত (কোড যেমন NEC0017)।","Handles transactions on behalf of customers; in the system an agency outlet is called a “Franchise” (code e.g. NEC0017)."],
 ["Teller","Agency-র কাউন্টারে লেনদেন করা ইউজার।","A user who processes transactions at the agency counter."],["TT (Telegraphic Transfer)","একটি রেমিট্যান্স লেনদেন।","A single remittance transaction."],
 ["TT Issue","নতুন টাকা পাঠানোর লেনদেন তৈরি (প্রেরকের দিক)।","Creating a new money-transfer transaction (sender side)."],["TT Payment","প্রাপকের কাছে টাকা পরিশোধ (প্রাপকের দিক)।","Paying the money out to the beneficiary (receiver side)."],
 ["Cancellation","লেনদেন বাতিল।","Cancelling a transaction."],["Correction","লেনদেনের তথ্য সংশোধন।","Correcting transaction details."],["Refund","বাতিল লেনদেনের টাকা গ্রাহককে ফেরত।","Returning the money of a cancelled transaction to the customer."],
 ["Exchange Rate","মুদ্রা বিনিময় হার।","The currency conversion rate."],["Dealing Rate / Export Rate","পার্টনার বা দেশভিত্তিক নির্ধারিত রেট।","Rates set per partner or per country."],
 ["Corresponding / Correspondent Company","Payout পার্টনার — ব্যাংক, এক্সচেঞ্জ হাউস বা মোবাইল ওয়ালেট, যারা প্রাপককে টাকা দেয়।","Payout partner — a bank, exchange house or mobile wallet that pays the beneficiary."],
 ["Coverfund","পার্টনারকে Payout-এর জন্য আগাম পাঠানো অর্থ।","Money sent in advance to a partner to fund payouts."],
 ["AML (Anti-Money Laundering)","অর্থপাচার প্রতিরোধ।","Preventing money laundering."],["KYC (Know Your Customer)","গ্রাহকের পরিচয় যাচাই।","Verifying the customer's identity."],
 ["AVR (Adeguata Verifica Rafforzata)","উচ্চ-ঝুঁকির ক্ষেত্রে গ্রাহক ও লেনদেনের বাড়তি যাচাই (Enhanced Due Diligence)।","Enhanced due diligence on higher-risk customers and transactions."],
 ["PEP (Politically Exposed Person)","রাজনৈতিকভাবে গুরুত্বপূর্ণ ব্যক্তি।","A person in a prominent public/political position."],["SOS","সন্দেহজনক লেনদেনের রিপোর্ট।","Suspicious-transaction report."],
 ["Blacklist","কালো তালিকাভুক্ত ব্যক্তি, যাদের সাথে লেনদেন নিয়ন্ত্রিত।","Listed persons with whom transactions are restricted."],
 ["UIC (Unique Identification Code)","ইতালির রেফারেন্স ডেটা — অবস্থান, খাত, ঝুঁকির শ্রেণি, ডকুমেন্টের ধরন।","Italian reference data — locations, sectors, risk classes, document types."],
 ["MIT","Compliance সংস্থায় ডেটা প্রেরণ।","Data transmission to the compliance authority."],["Testkey","API ছাড়া ফাইলভিত্তিক পার্টনারের জন্য নিরাপত্তা কী।","Security key for file-based (non-API) partners."],
 ["General Ledger (GL)","সাধারণ খতিয়ান — সব হিসাবের মূল খাতা।","The main book of all accounts."],["Voucher","হিসাবের এন্ট্রি (ডেবিট/ক্রেডিট)।","An accounting entry (debit/credit)."],
 ["Trial Balance","সব হিসাবের ডেবিট-ক্রেডিট মিলিয়ে দেখার রিপোর্ট (রেওয়ামিল)।","Report that checks total debits against total credits."],
 ["End of Day (EOD)","দিনশেষের হিসাব ও অবস্থান নির্ধারণ।","Closing the day's accounts and positions."],["Hold / Unhold","সমস্যার কারণে লেনদেন আটকে রাখা / ছেড়ে দেওয়া।","Stopping / releasing a transaction because of an issue."],
 ["Menu ID / Menu Code","প্রতিটি Screen-এর নির্দিষ্ট পরিচয় নম্বর; এই নির্দেশিকায় Menu Map-এর Code ব্যবহার করা হয়েছে।","Each screen's identifier; this manual uses the codes from the Menu Map."],
 ["Web Service (WS) / API","পার্টনারের সিস্টেমের সাথে স্বয়ংক্রিয় সংযোগ।","Automatic connection to a partner's system."],
 ["MAC Address","কম্পিউটারের নেটওয়ার্ক পরিচয়; অনুমোদিত কম্পিউটার চিহ্নিত করতে ব্যবহৃত।","A computer's network identity, used to mark approved computers."]];
function glossaryPage(){
  return `<div class="crumb"><span><a href="#home" data-go="home">Home</a></span><span>${U("glossary")}</span></div><h1>${T("শব্দকোষ","Glossary")}<span class="en">${T("Glossary — গুরুত্বপূর্ণ শব্দ ও তাদের অর্থ","Key terms and what they mean")}</span></h1>
  <p class="lead">${T("System-এ ব্যবহৃত গুরুত্বপূর্ণ English শব্দগুলো অপরিবর্তিত রাখা হয়েছে; এখানে সহজ বাংলায় অর্থ দেওয়া হলো। শব্দে ক্লিক করলে কপি হবে।","Important system terms with a plain explanation. Click a term to copy it.")}</p>`
   + H2(1,"terms",T("শব্দের তালিকা","Terms")) + `<table><tr><th style="width:38%">${T("শব্দ (English)","Term")}</th><th>${T("সহজ বাংলা অর্থ","Meaning")}</th></tr>${GLOSS.map(g=>`<tr><td><code class="ui term">${esc(g[0])}</code></td><td>${esc(isEn()?g[2]:g[1])}</td></tr>`).join("")}</table>`;
}
const RULES = [
 ["BR-001","Accounting","ভাউচার পোস্ট করার আগে যাচাই ও যথাযথ অনুমোদন প্রয়োজন।","Vouchers must be checked and properly approved before posting."],
 ["BR-002","Central Admin / Exchange / Agency","লেনদেনের রেট নির্ধারিত সর্বনিম্ন ও সর্বোচ্চ সীমার মধ্যে যাচাই হয়; অনুমোদিত/পাবলিক রেট Agency-র জন্য প্রকাশ করা হয়।","Transaction rates are checked against configured minimum and maximum limits; approved/public rates are published to agencies."],
 ["BR-003","Administrator / Central Admin","Remitter-এর লেনদেন সীমা দিন, মাস ও বছর অনুযায়ী যাচাই হয়; Administrator লেনদেন/Remitter/Beneficiary সীমা নির্ধারণ করেন।","Remitter limits are checked by day, month and year; the Administrator configures transaction, Remitter and Beneficiary limits."],
 ["BR-004","Central Admin / Exchange / Agency","Blacklist যাচাই রেমিট্যান্স নিয়ন্ত্রণের অংশ; Agency লেনদেনের আগে Blacklist যাচাই করে।","Blacklist checking is part of remittance control; the Agency checks the blacklist before processing."],
 ["BR-005","Central Admin / Exchange / Agency","উচ্চ-ঝুঁকির রেমিট্যান্সে AVR তথ্য/পর্যালোচনা লাগে এবং Export-এর আগে Hold হতে পারে।","Higher-risk remittances need AVR information/review and may be held before export."],
 ["BR-006","Administrator / Exchange / Agency","Remitter/Agent ডকুমেন্টের মেয়াদ ও অবস্থা (missing, uploaded, expired) ট্র্যাক করা হয়।","Remitter/Agent document validity and status (missing, uploaded, expired) are tracked."],
 ["BR-007","Administrator / Exchange / Agency","Agent ও স্টাফের প্রবেশ অনুমোদিত ডিভাইস/অ্যাক্সেস নিয়ন্ত্রণের মাধ্যমে হয়।","Agent and staff access goes through approved devices/access controls."],
 ["BR-008","Central Admin / Exchange","TT-র কোম্পানি, ব্যাংক বা প্রসেসিং স্ট্যাটাস পরিবর্তনের আগে Central Admin-এর অনুমোদন লাগে।","Changing a TT's company, bank or processing status needs Central Admin authorisation."],
 ["BR-009","Central Admin / Exchange / Agency / Accounting","TT বাতিল ও সংশোধন সম্পন্নের আগে পর্যালোচনা/অনুমোদন লাগে; অনুমোদনের পর Agency Refund দেয়।","TT cancellation and correction need review/approval; the Agency refunds after approval."],
 ["BR-010","Accounting / Settlement","গ্রাহকের রেমিট্যান্সের টাকা NEC-এর নিজস্ব তহবিল থেকে আলাদা করে ট্র্যাক করতে হয়।","Customer remittance funds must be tracked separately from NEC's own funds."],
 ["BR-011","All modules","গুরুত্বপূর্ণ হিসাব কার্যক্রম, প্রবেশ, Remitter/Beneficiary/TT পরিবর্তন ও স্ট্যাটাস ইতিহাস সংরক্ষিত ও দৃশ্যমান থাকে।","Important accounting actions, access, Remitter/Beneficiary/TT changes and status history are kept and visible."],
 ["BR-012","Administrator / Integration","Production Integration অনুমোদিত Authentication ও নিরাপদ যোগাযোগ ব্যবহার করে; টেস্ট Credential আলাদা থাকে।","Production integrations use approved authentication and secure communication; test credentials stay separate."],
 ["BR-013","Accounting / Migration","বিদ্যমান হিসাবের ডেটা ইমপোর্ট হয়; ব্যর্থ বা অমিল এন্ট্রি আলাদাভাবে নিষ্পত্তি হয়।","Existing accounting data is imported; failed or mismatched entries are resolved separately."],
 ["BR-014","All channels / Integration","প্রতিটি রেমিট্যান্সের একটি মাত্র প্রামাণ্য (authoritative) স্ট্যাটাস থাকে।","Each remittance has a single authoritative status."],
 ["BR-015","All channels / Integration","স্ট্যাটাস পরিবর্তন অনুমোদিত নিয়মে হয়, উৎস ও সময় সংরক্ষিত থাকে, পার্টনারের স্ট্যাটাস EFT স্ট্যাটাসে রূপান্তরিত হয়।","Status changes follow approved rules, with source and time stored; partner statuses are mapped to EFT statuses."]];
function rulesPage(){
  return `<div class="crumb"><span><a href="#home" data-go="home">Home</a></span><span>Business Rules</span></div><h1>${U("rules")}<span class="en">${T("Business Rules & Controls (HLBR v1.0 · Section 11)","HLBR v1.0 · Section 11")}</span></h1>
  <p class="lead">${T("নিচের নিয়মগুলো “NEC EFT – Business & High-Level Requirements v1.0” ডকুমেন্টের Section 11 থেকে সহজ বাংলায় নেওয়া। Feature পাতার Important Notes-এ এই ID-গুলো উল্লেখ করা হয়েছে।","These rules are summarised from Section 11 of “NEC EFT – Business & High-Level Requirements v1.0”. Feature pages cite these IDs in Important Notes.")}</p>`
   + H2(1,"br",T("নিয়মের তালিকা","Rules")) + `<table><tr><th>Rule ID</th><th>${T("প্রযোজ্য","Applies to")}</th><th>${T("নিয়ম","Rule")}</th></tr>${RULES.map(r=>`<tr><td><code class="ui term">${r[0]}</code></td><td>${esc(r[1])}</td><td>${esc(isEn()?r[3]:r[2])}</td></tr>`).join("")}</table>
   <div class="callout info">${T("এই ডকুমেন্টটি নতুন EFT System-এর লক্ষ্য-চাহিদা (Requirement); বর্তমান System-এ প্রতিটি নিয়ম হুবহু একইভাবে প্রয়োগ হয় কিনা তা সংশ্লিষ্ট Screen-এ যাচাই করে নিন।","That document states requirements for the new EFT system; check on the relevant screen whether the current system applies each rule exactly the same way.")}</div>`;
}
function lifecyclePage(){
  const go = t => { const id = ORDER.find(i=>P[i].p===t); return id?`<a href="#${id}" data-go="${id}">${esc(t.split(" › ").pop())}</a>`:esc(t); };
  const steps = [
   ["শাখা চালুর আগে (Before Branch Start)","Before Branch Start","Head Office দিনের রেট প্রকাশ করে এবং Testkey ও Dealing Account প্রস্তুত রাখে।","Head Office publishes the day's rates and prepares Testkeys and dealing accounts.",["Central Admin › Daily Tasks › Before Branch Start › Base Rate Setup","Central Admin › Daily Tasks › Before Branch Start › Minimum and Maximum Rate"]],
   ["Agency-তে TT Issue","TT Issue at the Agency","Teller Remitter ও Beneficiary নির্বাচন/তৈরি করে TT Issue করেন — চার্জ, কমিশন ও রেট প্রয়োগ হয়, প্রয়োজনে AVR নেওয়া হয় এবং Receipt প্রিন্ট হয়।","The Teller selects/creates the Remitter and Beneficiary and issues the TT — charges, commission and rate apply, AVR is taken if needed, and a receipt is printed.",["Agency › Remittance › New Remitter","Agency › Remittance › New Beneficiary","Agency › Remittance › TT Issue"]],
   ["অনুমোদন ও Hold","Authorisation and Hold","Exchange/Central Admin Remitter ও লেনদেন অনুমোদন করে, TT Authorise করে; প্রয়োজনে Hold (সাধারণ, Blacklist বা Franchise) করে।","Exchange/Central Admin approve the Remitter and transaction and authorise the TT; if needed they hold it (regular, blacklist or franchise hold).",["Central Admin › Daily Tasks › Sending of TT › Authorise TT","Central Admin › Daily Tasks › Sending of TT › Hold/Unhold TT (Regular)"]],
   ["পার্টনারে পাঠানো (Sending of TT)","Sending to the partner","Central Admin Export ফাইল (File Format + Testkey) বা পার্টনার API-এর মাধ্যমে TT পাঠায়।","Central Admin sends the TT by export file (file format + Testkey) or partner API.",["Central Admin › Daily Tasks › Sending of TT › Sending of TT"]],
   ["স্ট্যাটাস হালনাগাদ","Status updates","Web Service, পেমেন্ট নিশ্চিতকরণ ফাইল বা Webhook থেকে স্ট্যাটাস আসে → TT পরিশোধিত। ব্যতিক্রমে Undo Send, Resend বা ব্যাংক-শাখা পরিবর্তন।","Status arrives by web service, payment-confirmation file or webhook → the TT is paid. Exceptions: undo send, resend or change bank branch.",["Central Admin › Daily Tasks › Sending of TT › Update Status From WS","Central Admin › Daily Tasks › Sending of TT › Undo Send TT"]],
   ["বাতিল / সংশোধন","Cancellation / correction","Agency আবেদন করে → Exchange/Central Admin প্রক্রিয়া করে → Refund; GL-এ বিপরীত এন্ট্রি হয়।","The Agency applies → Exchange/Central Admin process it → refund; a reversing entry is posted in the GL.",["Agency › Remittance › Apply for TT Cancel","Central Admin › Daily Tasks › General Control › TT Cancellation Process"]],
   ["দিনশেষ, মাসশেষ ও বছরশেষ","End of day, month and year","Coverfund সারসংক্ষেপ, বিবরণী, আয় ও অবস্থান → GL ভাউচার; মাসশেষে আয় ভাগাভাগি ও কমিশন; বছরশেষে চূড়ান্ত হিসাব।","Coverfund summary, statements, earnings and positions → GL vouchers; at month end income sharing and commission; at year end the final accounts.",["Central Admin › Daily Tasks › End of Day › Daily Coverfund Summary","Exchange › Daily Task › Month End Process › Income Sharing Process"]]];
  return `<div class="crumb"><span><a href="#home" data-go="home">Home</a></span><span>${U("lifecycle")}</span></div><h1>${T("একটি TT-এর জীবনচক্র","The life of a TT")}<span class="en">${T("TT Lifecycle — Agency থেকে প্রাপক পর্যন্ত","From the Agency to the beneficiary")}</span></h1>
  <p class="lead">${T("একটি রেমিট্যান্স (TT) কোন কোন ধাপ পেরিয়ে প্রাপকের কাছে পৌঁছায় এবং প্রতিটি ধাপে কোন Screen ব্যবহার হয়।","The stages a remittance (TT) passes through before reaching the beneficiary, and the screens used at each stage.")}</p>
  <div class="callout warn">${T("এই ধারাক্রম System-এর মেনু কাঠামো দেখে তৈরি (Screens Knowledge Base, Section 4) — কোনো একক Source ডকুমেন্টে সরাসরি লেখা প্রক্রিয়া নয়।","This sequence is inferred from the system's menu structure (Screens Knowledge Base, Section 4) — it is not written as a process in any single source document.")} <span class="guess">${T("অনুমান","Assumption")}</span></div>`
   + H2(1,"flow",T("ধাপসমূহ","Stages")) + `<ol class="steps">${steps.map(s=>`<li><span class="stt">${esc(isEn()?s[1]:s[0])}</span>${esc(isEn()?s[3]:s[2])}<br><span style="font-size:14px">${T("সংশ্লিষ্ট Screen:","Screens:")} ${s[4].map(go).join(" · ")}</span></li>`).join("")}</ol>`;
}

/* ================= Router ================= */
const SPECIAL = {home:homePage, overview:overviewPage, glossary:glossaryPage, rules:rulesPage, lifecycle:lifecyclePage};
const specialTitle = id => ({home:"Home", overview:"Documentation Overview", glossary:U("glossary"), rules:"Business Rules", lifecycle:U("lifecycle")})[id];
let current = "home";
function render(id, push=true, keepScroll=false){
  if(!SPECIAL[id] && !P[id]) id = "home";
  current = id;
  main.innerHTML = SPECIAL[id] ? SPECIAL[id]() : (P[id].k==="screen" ? screenPage(P[id]) : menuPage(P[id]));
  BOOT.afterRender(id); main.querySelectorAll("canvas[data-img]").forEach(c => io.observe(c));
  document.querySelectorAll(".sidebar .nl").forEach(a => a.classList.toggle("active", a.dataset.go === id));
  if(P[id]) openTo(id);
  const act = document.querySelector(`#tree .nl[data-go="${id}"]`); if(act) act.scrollIntoView({block:"nearest"});
  buildToc(); addRecent(id);
  document.title = (P[id] ? P[id].en + (isEn() ? "" : " · " + P[id].bn) : specialTitle(id)) + " — " + U("brand");
  if(push && location.hash.slice(1) !== id) history.pushState(null, "", "#" + id);
  if(!keepScroll){ window.scrollTo({top:0}); main.focus({preventScroll:true}); }
  document.body.classList.remove("nav-open");
}
window.addEventListener("popstate", () => render(location.hash.slice(1) || "home", false));

/* ================= TOC + scroll-spy ================= */
let spy;
function buildToc(){
  const hs = [...main.querySelectorAll("h2[id]")];
  $("#toc").innerHTML = hs.map(h => `<a href="#${h.id}" data-sec="${h.id}">${esc(h.textContent.replace(/^\d+/, ""))}</a>`).join("");
  spy && spy.disconnect();
  spy = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting) $("#toc").querySelectorAll("a").forEach(a => a.classList.toggle("on", a.dataset.sec === e.target.id)); }), {rootMargin:"-70px 0px -70% 0px"});
  hs.forEach(h => spy.observe(h));
}

/* ================= Recently viewed ================= */
function addRecent(id){
  if(id === "home") return drawRecent();
  let r = (store("nec_recent") || []).filter(x => x !== id); r.unshift(id); store("nec_recent", r.slice(0, 5)); drawRecent();
}
function drawRecent(){
  const el = $("#recent");
  el.dataset.empty = U("noRecent");
  const rl = (store("nec_recent") || []).length; $("#recentHead").classList.toggle("has", rl > 0);
  el.innerHTML = (store("nec_recent") || []).filter(i => P[i] || SPECIAL[i]).map(i => `<button class="nl" data-go="${i}"><span class="ic">${svg("clock")}</span><span class="lbl">${esc(P[i] ? P[i].en : specialTitle(i))}${P[i] && P[i].k !== "module" ? `<small>· ${esc(P[i].mod)}</small>` : ""}</span></button>`).join("");
}

/* ================= Clicks: navigation, tree toggle, copy, zoom ================= */
document.addEventListener("click", e => {
  const tw = e.target.closest(".tw");
  if(tw){ e.preventDefault(); tw.closest(".node").classList.toggle("open"); return; }
  const g = e.target.closest("[data-go]");
  if(g){ e.preventDefault(); const id = g.dataset.go; if(g.classList.contains("sitem")) saveQ($("#sInput").value); if(navQ && g.closest("#tree")){ $("#navFilter").value = ""; navQ = ""; $("#sidebar").classList.remove("filtering"); $(".sb-search").classList.remove("has"); document.querySelectorAll("#tree .node").forEach(n => { n.classList.remove("hide"); const l = n.querySelector(":scope>.nl .lbl"); if(l.dataset.raw !== undefined) l.innerHTML = l.dataset.raw; }); $("#navEmpty").style.display = "none"; } if(id && id === location.hash.slice(1) && g.dataset.tw){ g.closest(".node").classList.toggle("open"); } render(id); closeSearch(); return; }
  const sec = e.target.closest("[data-sec]");
  if(sec){ e.preventDefault(); document.getElementById(sec.dataset.sec).scrollIntoView({behavior:"smooth"}); return; }
  const t = e.target.closest(".term");
  if(t){ const v = t.textContent.trim(); (navigator.clipboard ? navigator.clipboard.writeText(v) : Promise.reject()).then(() => toast(U("copied") + v), () => toast(v)); return; }
  const z = e.target.closest("[data-zoom]");
  if(z){ openLightbox(z.dataset.zoom, z.dataset.cap); }
});
function toast(m){ const t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 1500); }

/* ================= Lightbox with zoom ================= */
let zoom = 1;
function openLightbox(id, cap){ $("#lbCap").textContent = cap || ""; $("#lightbox").classList.add("show"); BOOT.paint($("#lbImg"), id).then(fitZoom); }
function setZoom(z){ zoom = Math.max(.25, Math.min(4, z)); const im = $("#lbImg"); im.style.width = (im.width * zoom) + "px"; }
function fitZoom(){ const im = $("#lbImg"); setZoom(Math.min(1, ($("#lbWrap").clientWidth - 20) / im.width)); }
$("#zIn").onclick = () => setZoom(zoom * 1.25); $("#zOut").onclick = () => setZoom(zoom / 1.25); $("#zFit").onclick = fitZoom;
$("#lbImg").onclick = () => setZoom(zoom < 1 ? 1 : zoom * 1.5);
$("#lbClose").onclick = () => $("#lightbox").classList.remove("show");
$("#lbWrap").addEventListener("click", e => { if(e.target.id === "lbWrap") $("#lightbox").classList.remove("show"); });

/* ================= Offline search (Bangla + English, both languages always searchable) ================= */
const IDX = D.index.map(([id, x]) => { const p = P[id]; return {id, x, hay:(p.en + " " + p.bn + " " + p.p + " " + p.code + " " + x).toLowerCase()}; });
["home","overview","glossary","rules","lifecycle"].forEach(id => IDX.push({id, x:"", hay:("home overview documentation glossary rules lifecycle tt-এর জীবনচক্র শব্দকোষ " + id + " " + (id==="glossary"?GLOSS.flat().join(" "):"") + (id==="rules"?RULES.flat().join(" "):"")).toLowerCase()}));
let sel = 0, hits = [], sTab = "all", lastWords = [];
const POPULAR = ["TT Issue","TT Payment","New Remitter","Black Listed People","Coverfund","Authorise TT","End of Day","Trial Balance","Exchange Rate","AVR"];
function openSearch(){ $("#overlay").classList.add("show"); const i = $("#sInput"); i.value = ""; sTab = "all"; doSearch(""); setTimeout(() => i.focus(), 20); }
function closeSearch(){ $("#overlay").classList.remove("show"); }
const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function pageText(id){ // text in the current language used for the snippet
  const p = P[id]; if(!p) return "";
  const parts = [isEn() ? p.pue : p.pu, ...p.sh.map(s => isEn() ? s.ce : s.c)].filter(Boolean).map(s => s.replace(/[`*]/g, "").trim());
  return [...new Set(parts)].join(" · ");
}
function snippet(x, w){
  if(!x) return "";
  const lx = x.toLowerCase(); let i = -1;
  for(const k of w){ const m = (k.length <= 3 && /^[a-z0-9]+$/.test(k)) ? lx.search(new RegExp("(?<![a-z0-9])" + reEsc(k) + "(?![a-z0-9])")) : lx.indexOf(k); if(m >= 0){ i = m; break; } }
  if(i < 0) return x.slice(0, 170) + (x.length > 170 ? "…" : "");
  const s = Math.max(0, i - 60); return (s ? "…" : "") + x.slice(s, s + 190) + (s + 190 < x.length ? "…" : "");
}
function hitTitle(id){ const p = P[id]; return p ? p.en : specialTitle(id); }
function recentQs(){ return (store("nec_sq") || []).slice(0, 6); }
function saveQ(q){ q = q.trim(); if(q.length < 2) return; store("nec_sq", [q, ...(store("nec_sq") || []).filter(x => x.toLowerCase() !== q.toLowerCase())].slice(0, 8)); }
const ICON_PATH = '<path d="M9 18l6-6-6-6"/>';
function emptyState(){
  const rq = recentQs();
  const chip = (q, ic) => `<button class="chip-s" data-q="${esc(q)}">${ic}${esc(q)}</button>`;
  const hist = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  const trend = '<svg viewBox="0 0 24 24"><path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg>';
  return `<div class="sempty">${rq.length ? `<h5>${T("সাম্প্রতিক খোঁজ","Recent searches")}</h5><div class="chips">${rq.map(q => chip(q, hist)).join("")}</div>` : ""}
    <h5>${T("জনপ্রিয় খোঁজ","Popular")}</h5><div class="chips">${POPULAR.map(q => chip(q, trend)).join("")}</div>
    <p class="shint">${U("sHelp")}</p></div>`;
}
function doSearch(q){
  const words = q.trim().toLowerCase().split(/\s+/).filter(Boolean); lastWords = words;
  $(".sbar").classList.toggle("has", !!q);
  if(!words.length){ hits = []; $("#sTabs").innerHTML = ""; requestAnimationFrame(updTabNav); $("#sRes").innerHTML = emptyState(); $("#sCount").textContent = ""; return; }
  let all = [];
  for(const it of IDX){
    const p = P[it.id], title = (p ? p.en + " " + p.bn : specialTitle(it.id)).toLowerCase(), path = p ? (p.p + " " + p.code).toLowerCase() : "";
    let s = 0, ok = true;
    for(const w of words){
      const short = w.length <= 3 && /^[a-z0-9]+$/.test(w);
      const has = str => short ? new RegExp("(^|[^a-z0-9])" + reEsc(w) + "([^a-z0-9]|$)").test(str) : str.includes(w);
      if(!has(it.hay)){ ok = false; break; } s += has(title) ? 10 : (has(path) ? 4 : 1); }
    if(!ok) continue;
    const q2 = words.join(" "), en = (p ? p.en : "").toLowerCase();
    if(en === q2) s += 100; else if(en.startsWith(q2)) s += 20;
    if(p && p.k === "screen") s += 1;
    all.push({...it, s, mod: p ? p.mod : "guide"});
  }
  all.sort((a, b) => b.s - a.s || hitTitle(a.id).length - hitTitle(b.id).length);
  // module tabs like Google's "All / Images / News"
  const cnt = {}; all.forEach(h => cnt[h.mod] = (cnt[h.mod] || 0) + 1);
  if(sTab !== "all" && !cnt[sTab]) sTab = "all";
  const order = [...MODS.map(m => P[m].en), "guide"].filter(m => cnt[m]);
  $("#sTabs").innerHTML = `<button class="stab ${sTab==="all"?"on":""}" data-tab="all">${T("সব","All")}<i>${isEn()?all.length:num(all.length)}</i></button>` +
    order.map(m => `<button class="stab ${sTab===m?"on":""}" data-tab="${esc(m)}">${m==="guide"?U("guide"):esc(m)}<i>${isEn()?cnt[m]:num(cnt[m])}</i></button>`).join("");
  { const on = $("#sTabs .stab.on"); if(on) on.scrollIntoView({block:"nearest", inline:"nearest"}); requestAnimationFrame(updTabNav); }
  const list = sTab === "all" ? all : all.filter(h => h.mod === sTab);
  hits = list.slice(0, 50); sel = 0;
  const wre = w => (w.length <= 3 && /^[a-z0-9]+$/.test(w)) ? "(?<![A-Za-z0-9])(" + reEsc(w) + ")(?![A-Za-z0-9])" : "(" + reEsc(esc(w)) + ")";
  const hl = s => { let h = esc(s); words.forEach(w => { h = h.replace(new RegExp(wre(w), "gi"), "<b>$1</b>"); }); return h; };
  const hlt = s => { let h = esc(s); words.forEach(w => { h = h.replace(new RegExp("(" + reEsc(esc(w)) + ")", "gi"), "<mark>$1</mark>"); }); return h; };
  $("#sRes").innerHTML = hits.length
    ? `<div class="smeta">${T(`প্রায় ${num(list.length)}টি ফলাফল`, `About ${list.length} result${list.length>1?"s":""}`)}</div>` + hits.map((h, i) => { const p = P[h.id];
        const crumb = p ? p.p.split(" › ").map((x, j, a) => j === a.length - 1 ? `<b>${esc(x)}</b>` : esc(x)).join(" › ") : U("guide");
        const fav = svg(p ? p.mod : "book");
        const kind = p ? (p.k === "screen" ? (p.sh.length ? `📷 ${isEn()?p.sh.length:num(p.sh.length)}` : "") : T(num(p.kids.length)+"টি অপশন", p.kids.length+" options")) : "";
        const sub = p && !isEn() ? `<small>${esc(p.bn)}</small>` : "";
        const tags = p ? [`<span class="tm">${esc(p.mod)}</span>`, `<span class="tc">${esc(p.code)}</span>`, kind ? `<span>${kind}</span>` : ""].join("") : `<span class="tm">${U("guide")}</span>`;
        return `<a href="#${h.id}" class="sitem ${i?"":"on"}" data-go="${h.id}">
          <span class="s-fav">${fav}</span>
          <span class="s-crumb">${crumb}</span>
          <span class="t">${esc(hitTitle(h.id))}${sub}</span>
          <span class="x">${hl(snippet(p ? pageText(h.id) : "", words))}</span>
          <span class="tags">${tags}</span></a>`; }).join("")
    : `<div class="snone"><b>${T(`“${esc(q)}” — কোনো ফলাফল পাওয়া যায়নি`, `No results for “${esc(q)}”`)}</b>${T("বানান দেখুন, অন্য শব্দ বা English/বাংলা দুটোতেই চেষ্টা করুন।","Check the spelling, or try other words — English or Bangla.")}</div>`;
  $("#sCount").textContent = "";
}
$("#sTabs").addEventListener("click", e => { const b = e.target.closest(".stab"); if(!b) return; sTab = b.dataset.tab; doSearch($("#sInput").value); $("#sInput").focus(); });
$("#sRes").addEventListener("click", e => { const c = e.target.closest(".chip-s"); if(c){ $("#sInput").value = c.dataset.q; doSearch(c.dataset.q); $("#sInput").focus(); } }, true);

/* tab strip arrows: visible only when more tabs are hidden on that side */
function updTabNav(){ const s = $("#sTabs"), w = $("#sTabsWrap");
  w.classList.toggle("can-l", s.scrollLeft > 4); w.classList.toggle("can-r", s.scrollLeft + s.clientWidth < s.scrollWidth - 4); }
$("#sTabs").addEventListener("scroll", updTabNav, {passive:true});
window.addEventListener("resize", updTabNav);
$("#tL").onclick = () => { const s = $("#sTabs"); s.scrollBy({left: -s.clientWidth * .7}); };
$("#tR").onclick = () => { const s = $("#sTabs"); s.scrollBy({left: s.clientWidth * .7}); };
$("#sTabs").addEventListener("wheel", e => { if(Math.abs(e.deltaY) > Math.abs(e.deltaX)){ e.preventDefault(); $("#sTabs").scrollLeft += e.deltaY; } }, {passive:false});
$("#sClear").onclick = () => { $("#sInput").value = ""; doSearch(""); $("#sInput").focus(); };
$("#sEsc").onclick = closeSearch;
$("#sInput").oninput = e => doSearch(e.target.value);
$("#openSearch").onclick = openSearch;
$("#overlay").onclick = e => { if(e.target.id === "overlay") closeSearch(); };
document.addEventListener("keydown", e => {
  const open = $("#overlay").classList.contains("show");
  if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k"){ e.preventDefault(); openSearch(); return; }
  if(e.key === "/" && !open && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)){ e.preventDefault(); openSearch(); return; }
  if(e.key === "Escape"){ closeSearch(); $("#lightbox").classList.remove("show"); }
  if(open && hits.length && (e.key === "ArrowDown" || e.key === "ArrowUp")){
    e.preventDefault(); sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + hits.length) % hits.length;
    document.querySelectorAll(".sitem").forEach((a, i) => { a.classList.toggle("on", i === sel); if(i === sel) a.scrollIntoView({block:"nearest"}); });
  }
  if(open && e.key === "Enter" && hits[sel]){ e.preventDefault(); saveQ($("#sInput").value); render(hits[sel].id); closeSearch(); }
});

/* ================= Language switch (persisted) ================= */
function applyLang(){
  const root = document.documentElement;
  root.dataset.lang = LANG; root.lang = LANG;
  document.querySelectorAll("[data-i]").forEach(el => { el.textContent = U(el.dataset.i); });
  $("#sInput").placeholder = U("sPh");
  $("#menuBtn").setAttribute("aria-label", T("মেনু খুলুন","Open menu"));
  $("#navFilter").placeholder = U("filterPh");
  document.querySelectorAll("[data-ico]").forEach(el => { el.innerHTML = svg(el.dataset.ico); });
  buildTree(); drawRecent();
}
function setLang(l){
  LANG = l; store("nec_lang", l);
  const y = window.scrollY; applyLang(); render(current, false, true); window.scrollTo({top:y});
}
$("#navFilter").addEventListener("input", e => filterNav(e.target.value));
$("#navFilter").addEventListener("keydown", e => { if(e.key === "Escape"){ e.target.value = ""; filterNav(""); e.target.blur(); }
  if(e.key === "Enter"){ const f = document.querySelector("#tree .node:not(.hide)>.nl mark.f"); if(f) f.closest(".nl").click(); } });
$("#navClear").onclick = () => { $("#navFilter").value = ""; filterNav(""); $("#navFilter").focus(); };
$("#recentClear").onclick = () => { store("nec_recent", []); drawRecent(); };
$("#collapseAll").onclick = () => document.querySelectorAll("#tree .node.open").forEach(n => n.classList.remove("open"));
$("#langBtn").onclick = () => setLang(isEn() ? "bn" : "en");

/* ================= Theme (persisted) ================= */
const root = document.documentElement;
const SUN = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
const MOON = '<svg viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
function setTheme(t){ root.dataset.theme = t; $("#themeBtn").innerHTML = t === "dark" ? SUN : MOON; store("nec_theme", t); }
$("#themeBtn").onclick = () => setTheme(root.dataset.theme === "dark" ? "light" : "dark");
$("#menuBtn").onclick = () => document.body.classList.toggle("nav-open");
$("#printBtn").onclick = async () => { await Promise.all([...main.querySelectorAll("canvas[data-img]")].map(c => { const id = c.dataset.img; c.removeAttribute("data-img"); return BOOT.paint(c, id); })); main.querySelectorAll("details").forEach(d => d.open = true); setTimeout(() => window.print(), 300); };
$("#topBtn").onclick = () => window.scrollTo({top:0, behavior:"smooth"});

/* ================= Init ================= */
window.APP = { render: (id, keep) => render(id || current, false, keep), current: () => current, isEn: () => isEn() };
setTheme(store("nec_theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
applyLang();
render(location.hash.slice(1) || "home", false);

}
