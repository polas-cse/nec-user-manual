# -*- coding: utf-8 -*-
import json, re, os, hashlib, base64, collections, html
from bn_names import BN
from content import ROLES, notes_for, problems_for, BTN_RESULT

B = "/home/claude/build"
M = json.load(open(f"{B}/menu.json"))
IMGS = json.load(open(f"{B}/imgs.json")) + json.load(open(f"{B}/late.json"))
DOCS = sorted(set(o["doc"] for o in json.load(open(f"{B}/imgs.json"))))
# doc list order on device (sorted listing of media folders)
DEVDOCS = ['2 Features Extract and Explanation','2.1 Features Extract and Explanation','2.2 Features Extract and Explanation',
           '3 Features Extract and Explanation','4.1 Features Extract and Explanation','4.2 Features Extract and Explanation',
           '5.1 Features Extract and Explanation','Features Extract and Explanation','Part 1 Features Extract and Explanation',
           'Part 1.1 Features Extract and Explanation']

def webp_name(o):
    if o["doc"] == "late":
        n = o["src"][11:-4].replace(" ", "_").replace("(", "").replace(")", "")
        return f"L_{n}.webp"
    i = DEVDOCS.index(o["doc"])
    return f"d{i}_{os.path.splitext(os.path.basename(o['src']))[0]}.webp"

# ---------- images: dedupe by content ----------
IMGDIR = f"{B}/img/webp"
hash2id, imgdata, missing_files = {}, {}, []
def img_id(fn):
    p = f"{IMGDIR}/{fn}"
    if not os.path.exists(p): missing_files.append(fn); return None
    raw = open(p, "rb").read()
    h = hashlib.md5(raw).hexdigest()
    if h not in hash2id:
        iid = f"i{len(hash2id)}"; hash2id[h] = iid; imgdata[iid] = base64.b64encode(raw).decode()
    return hash2id[h]

# ---------- menu tree ----------
rows = [r for r in M if r["path"]]
path2row = {r["path"]: r for r in rows}
def pid(r): return "m" + r["code"].replace(".", "-")
children = collections.defaultdict(list)
for r in rows:
    if " › " in r["path"]: children[r["path"].rsplit(" › ", 1)[0]].append(r["path"])
bypath_imgs = collections.defaultdict(list)
for o in IMGS:
    if o["path"]: bypath_imgs[o["path"]].append(o)

def clean_desc(d):
    d = re.sub(r"\*\*|\{\.underline\}|\\$", "", d)
    d = re.sub(r"\s+", " ", d).strip()
    return d

def fields_from(descs):
    out = []
    for d in descs:
        for m in re.finditer(r"যেখানে(.+?)(?:দেখা যায়|থাকে|পূরণ|নির্বাচন|সেট|দিয়ে|লিখে|বেছে|;|।|$)", d):
            seg = re.sub(r"\([^)]*\)", "", m.group(1))
            seg = re.sub(r"\"[^\"]*\"", "", seg)
            for part in re.split(r",|\s+ও\s+|\s+এবং\s+|—|/", seg):
                p = part.strip(" `.:;-–")
                p = re.sub(r"^(উপরে|নিচে|মাঝের টেবিলে|ডান পাশে|বাম পাশে|টেবিলে)\s*", "", p)
                p = re.sub(r"\s*(কলামে|কলাম|ঘরে|ড্রপডাউন|অপশন|বাটন|চেকবক্স|ফিল্ড|অংশে|অংশ|তালিকা).*$", "", p)
                if 2 <= len(p) <= 40 and re.search(r"[A-Za-z]", p) and not re.search(r"[ঀ-৿]{4,}", p):
                    if p not in out: out.append(p)
    return out[:24]

KNOWN_BTN = set("Save Close Search Preview Print Refresh Reload Load Export Add Edit Delete Send Cancel OK Validate Download Detail Summary Generate Process Authorise Authorize Approve New Update Show Find Clear Encrypt View".split())
BTN_WORDS = ["Save","Search Client","Search","Preview","Print Settings","Print","Refresh","Reload","Load now","Export to Excel","Export","Add","Edit","Delete","Send","Validate","Download","Detail","Summary","Process Now","Draft Copy","Encrypt","Generate Otp and Send Mail","Re-print Remittance","OK","Close"]
def buttons_from(descs):
    out = []
    joined = " ".join(descs)
    for w in BTN_WORDS:
        if re.search(r"(?<![A-Za-z])`?" + re.escape(w) + r"`?(?![A-Za-z])\s*(?:বাটন|-এ ক্লিক|-তে ক্লিক|করে|করতে|করা|ও `|,|বা)", joined) and w not in out:
            if not any(w != o and w in o for o in out): out.append(w)
    for d in descs:
        for t in re.findall(r"`([^`›]{1,28})`", d):
            t = t.strip()
            w = t.split()[0] if t else ""
            if (w in KNOWN_BTN or t in ("Load now", "Export to Excel", "Process Now", "Draft Copy", "Search Client", "Print Settings", "Re-print Remittance")) and t not in out:
                out.append(t)
    return out

def win_titles(descs):
    out = []
    for d in descs:
        for t in re.findall(r"[\"“]([^\"”]{3,70})[\"”]\s*(?:উইন্ডো|রিপোর্ট)", d):
            if t not in out: out.append(t)
    return out

def purpose_from(path, descs):
    for d in descs:
        if len(d) < 360 and re.search(r"(দেখা যাবে|করা যাবে|করতে হবে|খুলবে|জন্য)", d) and "উইন্ডো খুলে যায়" not in d:
            return d
    bn = BN.get(path.split(" › ")[-1], path.split(" › ")[-1])
    return f"এই Screen থেকে **{bn}** সংক্রান্ত কাজ করা হয়।"

def steps_for(path, title_list, has_fields, buttons, kind):
    parts = path.split(" › ")
    st = []
    if parts[0] != "File" or parts[-1] not in ("Login",):
        st.append(("System-এ Login করুন", "নিজের User ID ও Password দিয়ে NEC EFT System-এ প্রবেশ করুন। মূল উইন্ডোর উপরে Menu Bar দেখা যাবে।"))
    st.append((f"`{parts[0]}` মেনুতে ক্লিক করুন", f"উপরের Menu Bar থেকে **{parts[0]}** ({BN.get(parts[0], parts[0])}) মেনুতে ক্লিক করুন।"))
    for p in parts[1:-1]:
        st.append((f"`{p}`-এ মাউস রাখুন", f"**{p}** ({BN.get(p, p)})-এর উপর মাউস রাখলে (hover) এর সাব-মেনু খুলবে।"))
    if len(parts) > 1:
        leaf = parts[-1]
        extra = f" “{title_list[0]}” উইন্ডো খুলবে।" if title_list else ""
        if kind == "menu":
            st.append((f"`{leaf}`-এ মাউস রাখুন", f"**{leaf}**-এর উপর মাউস রাখলে এর ভেতরের Screen-গুলোর তালিকা দেখা যাবে; প্রয়োজনীয় Screen-এ ক্লিক করুন।"))
            return st
        st.append((f"`{leaf}`-এ ক্লিক করুন", f"**{leaf}** ({BN.get(leaf, leaf)})-এ ক্লিক করুন।{extra}"))
    if has_fields:
        st.append(("প্রয়োজনীয় তথ্য দিন", "উইন্ডোর ঘরগুলো (নিচের “প্রয়োজনীয় তথ্য” অংশ দেখুন) পূরণ বা ড্রপডাউন থেকে নির্বাচন করুন।"))
    act = [b for b in buttons if b not in ("Close",)]
    if act:
        st.append(("কাজ সম্পন্ন করুন", "কাজ অনুযায়ী " + ", ".join(f"`{b}`" for b in act[:6]) + " বাটন ব্যবহার করুন।" + (" কাজ শেষে `Close` দিয়ে উইন্ডো বন্ধ করুন।" if "Close" in buttons else "")))
    elif "Close" in buttons:
        st.append(("উইন্ডো বন্ধ করুন", "কাজ শেষে `Close` বাটনে ক্লিক করে উইন্ডো বন্ধ করুন।"))
    return st

def result_for(buttons, titles, kind, path):
    if path.startswith("Windows"):
        return ["নির্বাচিত বিন্যাস অনুযায়ী খোলা উইন্ডোগুলো সাজানো (বা বন্ধ) হবে।"]
    out = []
    if titles: out.append(f"মেনুতে ক্লিক করলে “{titles[0]}” উইন্ডো খুলবে।")
    bset = set(buttons)
    for keys, txt in BTN_RESULT:
        if any(k in bset for k in keys) and txt not in out: out.append(txt)
    if not out: out.append("নির্বাচিত Screen খুলবে এবং সংশ্লিষ্ট তথ্য দেখা যাবে।")
    return out

# ---------- build pages ----------
pages, order = {}, []
for r in rows:
    path = r["path"]; parts = path.split(" › "); leaf = parts[-1]
    kind = "screen" if r["type"] == "Screen" or not children.get(path) else "menu"
    if r["type"] == "Main Menu": kind = "module"
    shots = []
    for o in bypath_imgs.get(path, []):
        iid = img_id(webp_name(o))
        if not iid: continue
        cap = clean_desc(o["desc"])
        if any(s["i"] == iid for s in shots): continue
        shots.append(dict(i=iid, c=cap, l=1 if o["doc"] == "late" else 0))
    descs = [s["c"] for s in shots if s["c"]]
    pg = dict(id=pid(r), p=path, en=leaf, bn=BN.get(leaf, leaf), code=r["code"], k=kind,
              mod=parts[0], kids=[pid(path2row[c]) for c in children.get(path, [])],
              parent=pid(path2row[path.rsplit(" › ", 1)[0]]) if " › " in path else None, sh=shots)
    if kind == "screen":
        titles = win_titles(descs); flds = fields_from(descs); btns = buttons_from(descs)
        pg.update(pu=purpose_from(path, descs), ro=ROLES.get(parts[0], []), st=steps_for(path, titles, bool(flds), btns, kind),
                  fl=flds, bt=btns, rs=result_for(btns, titles, kind, path), no=notes_for(path, " ".join(descs)),
                  pr=problems_for(path, " ".join(descs), btns))
    else:
        pg.update(pu=None, ro=ROLES.get(parts[0], []), st=steps_for(path, [], False, [], "menu") if kind == "menu" else [])
    pages[pg["id"]] = pg; order.append(pg["id"])

# similar screens (same leaf in another module) for pages w/o screenshots
byleaf = collections.defaultdict(list)
for p in pages.values():
    if p["sh"]: byleaf[p["en"].lower()].append(p["id"])
for p in pages.values():
    if p["k"] == "screen" and not p["sh"]:
        p["sim"] = byleaf.get(p["en"].lower(), [])[:3]

# related = siblings (screens)
for p in pages.values():
    if p["parent"]:
        sib = [k for k in pages[p["parent"]]["kids"] if k != p["id"]]
        p["rel"] = sib[:8]

# prev/next over screens only, in menu order
screens = [i for i in order if pages[i]["k"] == "screen"]
for n, i in enumerate(screens):
    pages[i]["pv"] = screens[n - 1] if n else None
    pages[i]["nx"] = screens[n + 1] if n + 1 < len(screens) else None

# ---------- search index ----------
def strip_md(t): return re.sub(r"[`*]", "", t or "")
INDEX = []
for i in order:
    p = pages[i]
    txt = " ".join([strip_md(p.get("pu") or "")] + [strip_md(s["c"]) for s in p["sh"]] + p.get("fl", []) + [n["s"] for n in p.get("no", [])])
    INDEX.append([i, txt[:1600]])

stats = dict(modules=sum(1 for p in pages.values() if p["k"] == "module"),
             menus=sum(1 for p in pages.values() if p["k"] == "menu"),
             screens=len(screens), shots=len(imgdata),
             withshot=sum(1 for i in screens if pages[i]["sh"]),
             noshot=[i for i in screens if not pages[i]["sh"]])
print("pages", len(pages), "screens", len(screens), "with shots", stats["withshot"], "unique imgs", len(imgdata), "missing files", missing_files[:5], len(missing_files))
json.dump(dict(pages=pages, order=order, index=INDEX, stats=stats), open(f"{B}/data.json", "w"), ensure_ascii=False)
json.dump(imgdata, open(f"{B}/imgdata.json", "w"))
