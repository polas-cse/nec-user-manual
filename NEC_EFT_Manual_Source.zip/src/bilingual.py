# -*- coding: utf-8 -*-
"""Adds English versions of every text field to data.json -> data_bi.json.
Screenshot/purpose texts come from the translated tr/out_*.json; template sentences from en_text.EN;
steps are regenerated in English from the same inputs."""
import json, glob, hashlib, re
from en_text import EN

B = "/home/claude/build"
d = json.load(open(f"{B}/data.json"))
P = d["pages"]
TR = {}
for f in sorted(glob.glob(f"{B}/tr/out_*.json")):
    TR.update(json.load(open(f)))
h = lambda s: hashlib.md5(s.encode()).hexdigest()[:10]
missing = []
def tr(s):
    if not s: return s
    k = h(s)
    if k in TR: return TR[k]
    missing.append(s); return s
def en(s):
    if s in EN: return EN[s]
    missing.append(s); return s

def steps_en(p):
    parts = p["p"].split(" › ")
    out = []
    bn = p["st"]
    if bn and bn[0][0].startswith("System-এ Login"):
        out.append(["Log in to the system", "Sign in to the NEC EFT System with your User ID and Password. The menu bar appears at the top of the main window."])
    out.append([f"Click the `{parts[0]}` menu", f"Click **{parts[0]}** in the menu bar at the top."])
    for x in parts[1:-1]:
        out.append([f"Point to `{x}`", f"Hover the mouse over **{x}** to open its sub-menu."])
    if len(parts) > 1:
        leaf = parts[-1]
        if p["k"] == "menu":
            out.append([f"Point to `{leaf}`", f"Hover over **{leaf}** to see the screens inside it, then click the one you need."])
            return out
        title = None
        for s in bn:
            m = re.search(r"“([^”]+)” উইন্ডো খুলবে", s[1])
            if m: title = m.group(1)
        out.append([f"Click `{leaf}`", f"Click **{leaf}**." + (f" The “{title}” window opens." if title else "")])
    for s in bn:
        if s[0] == "প্রয়োজনীয় তথ্য দিন":
            out.append(["Enter the required details", "Fill in the fields or choose from the dropdowns (see “Required information” below)."])
        elif s[0] == "কাজ সম্পন্ন করুন":
            act = [b for b in p.get("bt", []) if b != "Close"]
            out.append(["Complete the task", "Use the " + ", ".join(f"`{b}`" for b in act[:6]) + " button(s) as needed." + (" Click `Close` when finished." if "Close" in p.get("bt", []) else "")])
        elif s[0] == "উইন্ডো বন্ধ করুন":
            out.append(["Close the window", "Click `Close` when you have finished."])
    return out

def result_en(r):
    m = re.match(r"মেনুতে ক্লিক করলে “(.+)” উইন্ডো খুলবে।", r)
    if m: return f"Clicking the menu opens the “{m.group(1)}” window."
    return en(r)

for p in P.values():
    p["en_t"] = p["en"]
    for s in p["sh"]: s["ce"] = tr(s["c"])
    if p.get("pu"):
        pe = TR.get(h(p["pu"]))
        if pe is None:
            m = re.match(r"এই Screen থেকে \*\*(.+)\*\* সংক্রান্ত কাজ করা হয়।", p["pu"])
            pe = f"Use this screen to work with **{p['en']}**." if m else tr(p["pu"])
        p["pue"] = pe
    p["roe"] = [[en(a), en(b)] for a, b in p.get("ro", [])]
    if p.get("st"): p["ste"] = steps_en(p)
    if p.get("rs"): p["rse"] = [result_en(r) for r in p["rs"]]
    for n in p.get("no", []): n["te"] = en(n["t"])
    for x in p.get("pr", []): x["qe"] = en(x["q"]); x["ae"] = en(x["a"])

# search index gets English text too
for row in d["index"]:
    p = P[row[0]]
    extra = " ".join([re.sub(r"[`*]", "", p.get("pue") or "")] + [re.sub(r"[`*]", "", s["ce"] or "") for s in p["sh"]])
    row[1] = (row[1] + " " + extra)[:3200]

json.dump(d, open(f"{B}/data_bi.json", "w"), ensure_ascii=False)
mb = [m for m in missing if re.search(r"[ঀ-৿]", m)]
print("missing translations:", len(mb)); [print(" ", m[:120]) for m in list(dict.fromkeys(mb))[:15]]
