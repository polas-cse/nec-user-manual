# -*- coding: utf-8 -*-
"""Builds the encrypted single-file manual.
- One random 256-bit content key encrypts the page data, the editor-changes blob and every image (AES-256-GCM).
- For each user ID the content key + role is wrapped with a key derived from that ID (PBKDF2-SHA256).
- Nothing readable (text, image, user list) is left in the HTML; only the login screen is plain.
Usage: python3 assemble_enc.py   -> NEC_EFT_User_Manual.html
"""
import base64, gzip, hashlib, json, os, random
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

B = os.path.dirname(os.path.abspath(__file__))
USERS = [  # ID (case-insensitive at login), role
    ("NEC-Apel", "editor"), ("NEC-Polas", "editor"), ("NEC-Rony", "editor"), ("NEC-Guest", "viewer"),
]
ITER = 600_000

b64 = lambda b: base64.b64encode(b).decode()
def enc(key, data):
    iv = os.urandom(12)
    return iv + AESGCM(key).encrypt(iv, data, None)

key = os.urandom(32)
salt = os.urandom(16)

# --- keyring: one wrapped entry per ID, shuffled, no names in clear ---
entries = []
for uid, role in USERS:
    dk = hashlib.pbkdf2_hmac("sha256", uid.upper().encode(), salt, ITER, 32)
    entries.append(b64(enc(dk, json.dumps({"k": b64(key), "role": role, "name": uid}).encode())))
random.shuffle(entries)
KR = b64(json.dumps({"v": 1, "salt": b64(salt), "iter": ITER, "users": entries}).encode())

# --- payload + empty edits ---
app = open(f"{B}/app.js", encoding="utf-8").read()
payload = '{"d":' + open(f"{B}/data_bi.json", encoding="utf-8").read() + ',"js":' + json.dumps(app, ensure_ascii=False) + '}'
PL = b64(enc(key, gzip.compress(payload.encode(), 9)))
ED = b64(enc(key, gzip.compress(b'{"t":{},"img":{},"del":{},"types":{}}')))

# --- images: each encrypted on its own so it can be decrypted only when shown ---
imgs = json.load(open(f"{B}/imgdata.json"))
blocks = "\n".join(f'<script type="application/octet-stream" id="{k}">{b64(enc(key, base64.b64decode(v)))}</script>' for k, v in imgs.items())

t = open(f"{B}/template.html", encoding="utf-8").read()
fr = b64(open(f"{B}/fonts/hs-Regular.woff2", "rb").read())
fb = b64(open(f"{B}/fonts/hs-SemiBold.woff2", "rb").read())
boot = open(f"{B}/boot.js", encoding="utf-8").read()
out = (t.replace("__FONT_R__", fr).replace("__FONT_B__", fb)
        .replace("__KR__", KR).replace("__PL__", PL).replace("__ED__", ED)
        .replace("__IMGS__", blocks)
        .replace("__BOOT__", boot.replace("</script", "<\\/script")).replace("__APP__", ""))
open(f"{B}/NEC_EFT_User_Manual.html", "w", encoding="utf-8").write(out)
print(round(len(out.encode()) / 1e6, 2), "MB; images:", len(imgs))
