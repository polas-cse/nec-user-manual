/* =====================================================================
   BOOT — login, decryption, protected images, role-based editing, save
   Everything in this file stays encrypted (AES-256-GCM) until a valid ID
   unwraps the content key. Images are decrypted only when drawn, straight
   onto <canvas>, so no image URL/data string ever appears in DOM or network.
   ===================================================================== */
"use strict";
// Snapshot of the pristine file (before any DOM change) — used to write the saved file
const ORIG_HTML = { text: "<!doctype html>\n" + document.documentElement.outerHTML };

const BOOT = (() => {
  const $ = s => document.querySelector(s);
  const te = new TextEncoder(), td = new TextDecoder();
  const b64d = s => { const bin = atob(s.trim()); const u = new Uint8Array(bin.length); for(let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  const b64e = u => { let s = ""; const C = 0x8000; for(let i = 0; i < u.length; i += C) s += String.fromCharCode.apply(null, u.subarray(i, i + C)); return btoa(s); };
  const KR = JSON.parse(atob($("#KR").textContent.trim()));      // keyring: salt + one wrapped key per ID
  let KEY = null, USER = null, EDITS = null, APPFN = null;
  const NEWIMG = {};                                               // id -> {bytes, type} uploaded this session
  const bmpCache = new Map();                                      // id -> ImageBitmap (memory only)
  let dirty = 0, fileHandle = null;

  /* ---------- crypto helpers ---------- */
  async function aesDecrypt(key, packed){ return new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM", iv: packed.subarray(0, 12)}, key, packed.subarray(12))); }
  async function aesEncrypt(key, bytes){ const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, bytes)); const o = new Uint8Array(12 + ct.length); o.set(iv); o.set(ct, 12); return o; }
  async function gunzip(u){ return new Uint8Array(await new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream("gzip"))).arrayBuffer()); }
  async function gzip(u){ return new Uint8Array(await new Response(new Blob([u]).stream().pipeThrough(new CompressionStream("gzip"))).arrayBuffer()); }
  async function deriveKey(id){
    const base = await crypto.subtle.importKey("raw", te.encode(id), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name:"PBKDF2", hash:"SHA-256", salt: b64d(KR.salt), iterations: KR.iter}, base, {name:"AES-GCM", length:256}, false, ["decrypt"]);
  }
  const normId = s => s.trim().toUpperCase().replace(/\s+/g, "");

  /* ---------- login ---------- */
  async function login(rawId){
    const id = normId(rawId); if(!id) throw new Error("empty");
    const dk = await deriveKey(id);
    for(const e of KR.users){
      try {
        const info = JSON.parse(td.decode(await aesDecrypt(dk, b64d(e))));
        KEY = await crypto.subtle.importKey("raw", b64d(info.k), "AES-GCM", false, ["encrypt", "decrypt"]);
        USER = {name: info.name, role: info.role, id};
        return true;
      } catch(_) { /* wrong ID for this entry */ }
    }
    throw new Error("bad");
  }
  async function loadPayload(){
    const pl = JSON.parse(td.decode(await gunzip(await aesDecrypt(KEY, b64d($("#PL").textContent)))));
    EDITS = await readEdits();
    APPFN = new Function(pl.js + "\nreturn startApp;")();      // the app code itself is part of the encrypted payload
    return pl.d;
  }
  async function readEdits(){
    const e = JSON.parse(td.decode(await gunzip(await aesDecrypt(KEY, b64d($("#ED").textContent)))));
    return Object.assign({t:{}, img:{}, del:{}, types:{}}, e);
  }

  /* ---------- protected images: decrypt -> ImageBitmap -> canvas ---------- */
  async function bitmap(id){
    if(bmpCache.has(id)) return bmpCache.get(id);
    const p = (async () => {
      let bytes, type = EDITS.types[id] || "image/webp";
      if(NEWIMG[id]){ bytes = NEWIMG[id].bytes; type = NEWIMG[id].type; }
      else { const el = document.getElementById(id); if(!el) throw new Error("img " + id); bytes = await aesDecrypt(KEY, b64d(el.textContent)); }
      return createImageBitmap(new Blob([bytes], {type}));
    })();
    bmpCache.set(id, p); return p;
  }
  async function paint(cv, id){
    try { const bmp = await bitmap(id); cv.width = bmp.width; cv.height = bmp.height; cv.getContext("2d").drawImage(bmp, 0, 0); cv.dataset.loaded = "1"; }
    catch(e){ cv.width = 600; cv.height = 60; const c = cv.getContext("2d"); c.fillStyle = "#999"; c.font = "16px sans-serif"; c.fillText("Image could not be loaded", 20, 36); }
  }
  // no "Save image as…", no dragging of screenshots
  document.addEventListener("contextmenu", e => { if(e.target.closest("canvas")) e.preventDefault(); }, true);
  document.addEventListener("dragstart", e => { if(e.target.closest("canvas")) e.preventDefault(); }, true);

  /* ---------- edit model ---------- */
  const isEditor = () => USER && USER.role === "editor";
  const mapImg = (pid, orig) => (EDITS && EDITS.img[pid + "|" + orig]) || orig;
  const isDeleted = (pid, orig) => !!(EDITS && EDITS.del[pid + "|" + orig]);
  const SEL = "h1,h2,h3,p,li,figcaption,.callout,summary,.ans,td,th,.roles .card b,.roles .card span,.lead,.fields span,.mcard b,.mcard > span";
  function editables(){
    const all = [...document.querySelectorAll("#main " + SEL.split(",").join(",#main "))];
    return all.filter(el => !all.some(o => o !== el && el.contains(o)));   // innermost blocks only
  }
  const keyOf = (idx) => (APP.isEn() ? "en" : "bn") + "|" + APP.current() + "|" + idx;
  // keep editors' text safe: plain text plus a few inline tags
  function sanitize(html){
    const doc = new DOMParser().parseFromString("<div>" + html + "</div>", "text/html");
    const OK = new Set(["B","STRONG","I","EM","U","CODE","SMALL","MARK","BR","SPAN","SUB","SUP"]);
    const walk = n => [...n.childNodes].forEach(c => {
      if(c.nodeType === 1){ if(!OK.has(c.tagName)){ c.replaceWith(...c.childNodes); walk(n); return; }
        [...c.attributes].forEach(a => { if(a.name !== "class") c.removeAttribute(a.name); }); walk(c); }
      else if(c.nodeType !== 3) c.remove(); });
    const root = doc.body.firstChild; walk(root); return root.innerHTML;
  }
  function afterRender(){
    if(!EDITS) return;
    const list = editables();
    list.forEach((el, i) => { el.dataset.ek = i; const v = EDITS.t[keyOf(i)]; if(v !== undefined){ el.innerHTML = v; el.classList.add("edited"); } });
    document.body.classList.toggle("can-edit", isEditor());
  }

  /* ---------- context menu (editors only) ---------- */
  const menu = document.createElement("div"); menu.className = "ctx"; menu.hidden = true; document.body.appendChild(menu);
  const L = (bn, en) => APP.isEn() ? en : bn;
  function showMenu(x, y, items){
    menu.innerHTML = items.map((it, i) => it === "-" ? '<hr>' : `<button data-i="${i}"${it.danger ? ' class="danger"' : ""}><span>${it.icon}</span>${it.label}</button>`).join("");
    menu.hidden = false;
    const r = menu.getBoundingClientRect();
    menu.style.left = Math.min(x, innerWidth - r.width - 8) + "px"; menu.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
    menu.onclick = e => { const b = e.target.closest("button"); if(!b) return; hideMenu(); items[+b.dataset.i].run(); };
  }
  const hideMenu = () => { menu.hidden = true; };
  document.addEventListener("click", e => { if(!menu.contains(e.target)) hideMenu(); });
  document.addEventListener("scroll", hideMenu, true);
  document.addEventListener("keydown", e => { if(e.key === "Escape") hideMenu(); });

  document.addEventListener("contextmenu", e => {
    if(!USER || !e.target.closest("#main")) return;
    e.preventDefault();
    if(!isEditor()){ toastB(L("আপনার শুধু দেখার অনুমতি আছে (Guest)।", "You have view-only access (Guest).")); return; }
    const items = [];
    const fig = e.target.closest("figure.shot");
    const cv = fig && fig.querySelector("canvas[data-orig]");
    if(cv){
      const pid = APP.current(), orig = cv.dataset.orig, k = pid + "|" + orig;
      items.push({icon:"🖼️", label:L("ছবি বদলান…", "Replace image…"), run: () => pickImage(k)});
      if(EDITS.img[k]) items.push({icon:"↺", label:L("মূল ছবিতে ফেরান", "Restore original image"), run: () => { delete EDITS.img[k]; changed(); }});
      items.push({icon:"🗑️", label:L("ছবি সরান", "Remove image"), danger:true, run: () => { EDITS.del[k] = 1; changed(); }});
    }
    const el = e.target.closest("[data-ek]");
    if(el && !(fig && !e.target.closest("figcaption"))){
      if(items.length) items.push("-");
      items.push({icon:"✏️", label:L("লেখা সম্পাদনা", "Edit text"), run: () => editText(el)});
      if(EDITS.t[keyOf(el.dataset.ek)] !== undefined) items.push({icon:"↺", label:L("মূল লেখায় ফেরান", "Restore original text"), run: () => { delete EDITS.t[keyOf(el.dataset.ek)]; changed(); }});
    }
    const delCount = Object.keys(EDITS.del).filter(k => k.startsWith(APP.current() + "|")).length;
    if(delCount){ if(items.length) items.push("-"); items.push({icon:"♻️", label:L(`সরানো ছবি ফিরিয়ে আনুন (${delCount})`, `Bring back removed images (${delCount})`), run: () => { Object.keys(EDITS.del).forEach(k => { if(k.startsWith(APP.current() + "|")) delete EDITS.del[k]; }); changed(); }}); }
    if(!items.length) return;
    showMenu(e.clientX, e.clientY, items);
  });

  function editText(el){
    const before = el.innerHTML, k = keyOf(el.dataset.ek);
    el.setAttribute("contenteditable", "plaintext-only");
    if(el.contentEditable !== "plaintext-only") el.setAttribute("contenteditable", "true");
    el.classList.add("editing"); el.focus();
    const sel = getSelection(), r = document.createRange(); r.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(r);
    const done = save => {
      el.removeAttribute("contenteditable"); el.classList.remove("editing");
      el.removeEventListener("keydown", onKey); el.removeEventListener("blur", onBlur);
      if(!save){ el.innerHTML = before; return; }
      const v = sanitize(el.innerHTML);
      if(v !== before){ EDITS.t[k] = v; el.innerHTML = v; el.classList.add("edited"); dirty++; updBar(); }
    };
    const onKey = ev => { if(ev.key === "Escape"){ ev.preventDefault(); done(false); } if(ev.key === "Enter" && !ev.shiftKey){ ev.preventDefault(); el.blur(); } };
    const onBlur = () => done(true);
    el.addEventListener("keydown", onKey); el.addEventListener("blur", onBlur);
  }
  function pickImage(k){
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/png,image/jpeg,image/webp,image/gif";
    inp.onchange = async () => {
      const f = inp.files[0]; if(!f) return;
      const id = "u" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      NEWIMG[id] = {bytes: new Uint8Array(await f.arrayBuffer()), type: f.type || "image/png"};
      EDITS.types[id] = NEWIMG[id].type; EDITS.img[k] = id; changed();
    };
    inp.click();
  }
  function changed(){ dirty++; updBar(); APP.render(null, true); }

  /* ---------- unsaved-changes bar + save ---------- */
  const bar = document.createElement("div"); bar.className = "savebar"; bar.hidden = true; document.body.appendChild(bar);
  function updBar(){
    bar.hidden = !dirty;
    bar.innerHTML = `<span>✎ ${L("সংরক্ষণ হয়নি এমন পরিবর্তন আছে", "You have unsaved changes")}</span>
      <button class="sv">${L("সংরক্ষণ করুন", "Save")} <kbd>Ctrl S</kbd></button><button class="dc">${L("বাতিল", "Discard")}</button>`;
    bar.querySelector(".sv").onclick = save; bar.querySelector(".dc").onclick = discard;
  }
  async function discard(){ for(const k in NEWIMG) delete NEWIMG[k]; EDITS = await readEdits(); dirty = 0; updBar(); APP.render(null, true); }
  document.addEventListener("keydown", e => { if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s" && isEditor()){ e.preventDefault(); if(dirty) save(); } });
  window.addEventListener("beforeunload", e => { if(dirty){ e.preventDefault(); e.returnValue = ""; } });

  async function buildFile(){
    // drop uploads that are no longer used
    const used = new Set(Object.values(EDITS.img));
    Object.keys(EDITS.types).forEach(id => { if(!used.has(id)) delete EDITS.types[id]; });
    let html = ORIG_HTML.text;
    const ed = b64e(await aesEncrypt(KEY, await gzip(te.encode(JSON.stringify(EDITS)))));
    html = html.replace(/(<script type="application\/octet-stream" id="ED">)[^<]*(<\/script>)/, (m, a, b) => a + ed + b);
    let blocks = "";
    for(const [id, im] of Object.entries(NEWIMG)){
      if(!used.has(id) || html.includes(`id="${id}"`)) continue;
      blocks += `<script type="application/octet-stream" id="${id}">${b64e(await aesEncrypt(KEY, im.bytes))}</script>\n`;
    }
    if(blocks) html = html.replace("<!--IMG-END-->", blocks + "<!--IMG-END-->");
    return html;
  }
  async function save(){
    if(!isEditor() || !dirty) return;
    const btn = bar.querySelector(".sv"); btn.disabled = true; btn.textContent = L("সংরক্ষণ হচ্ছে…", "Saving…");
    try {
      const html = await buildFile();
      const blob = new Blob([html], {type: "text/html"});
      if(window.showSaveFilePicker){
        if(!fileHandle) fileHandle = await showSaveFilePicker({suggestedName: "NEC_EFT_User_Manual.html", types: [{description: "HTML", accept: {"text/html": [".html"]}}]});
        const w = await fileHandle.createWritable(); await w.write(blob); await w.close();
      } else {
        const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "NEC_EFT_User_Manual.html"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      }
      ORIG_HTML.text = html;                                   // next save builds on this one
      dirty = 0; updBar(); toastB(L("সংরক্ষণ হয়েছে ✓ — এখন ফাইলটি git-এ commit করুন।", "Saved ✓ — now commit the file to git."));
    } catch(e){
      if(e && e.name === "AbortError"){ updBar(); return; }
      console.error(e); updBar(); toastB(L("সংরক্ষণ করা যায়নি: ", "Could not save: ") + (e && e.message || e));
    }
  }
  function toastB(m){ const t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(toastB.t); toastB.t = setTimeout(() => t.classList.remove("show"), 2600); }

  /* ---------- gate UI ---------- */
  function userChip(){
    const c = $("#userChip");
    const role = USER.role === "editor" ? L("Editor", "Editor") : L("শুধু দেখা", "View only");
    c.innerHTML = `<span class="av">${USER.name.replace(/^NEC-/i, "").slice(0, 1)}</span><span class="nm">${USER.name}<small>${role}</small></span><button id="logoutBtn" title="${L("লগ আউট", "Log out")}" aria-label="logout"><svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg></button>`;
    c.hidden = false;
    $("#logoutBtn").onclick = () => { if(dirty && !confirm(L("সংরক্ষণ না করা পরিবর্তন মুছে যাবে। লগ আউট করবেন?", "Unsaved changes will be lost. Log out?"))) return; dirty = 0; try{ sessionStorage.removeItem("nec_sid"); }catch(_){} location.hash = ""; location.reload(); };
  }
  async function enter(id, remember){
    await login(id);
    const data = await loadPayload();
    if(remember){ try{ sessionStorage.setItem("nec_sid", normId(id)); }catch(_){} }
    document.body.classList.remove("locked"); $("#gate").remove();
    APPFN(data);
    userChip(); updBar();
    if(isEditor()) toastB(L("লেখা বা ছবির উপর right-click করে edit করুন।", "Right-click any text or image to edit it."));
  }
  async function initGate(){
    const f = $("#gateForm"), inp = $("#gateId"), err = $("#gateErr"), btn = f.querySelector("button");
    try { const sid = sessionStorage.getItem("nec_sid"); if(sid){ btn.disabled = true; await enter(sid, false); return; } } catch(_) { btn.disabled = false; }
    inp.focus();
    f.onsubmit = async ev => {
      ev.preventDefault(); err.textContent = ""; btn.disabled = true; btn.classList.add("busy");
      try { await enter(inp.value, true); }
      catch(e){ btn.disabled = false; btn.classList.remove("busy"); err.textContent = e.message === "bad" || e.message === "empty" ? "ID সঠিক নয় · Invalid ID" : "ত্রুটি · Error: " + e.message; inp.select(); f.classList.remove("shake"); void f.offsetWidth; f.classList.add("shake"); }
    };
  }
  return {paint, mapImg, isDeleted, afterRender, initGate, user: () => USER};
})();
