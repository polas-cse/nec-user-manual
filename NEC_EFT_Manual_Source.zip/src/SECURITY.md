# Security notes — NEC EFT manual (encrypted build)

Commit **only** `NEC_EFT_User_Manual.html` to git. Do NOT commit this `src/` folder or
`data_bi.json` / `imgdata.json` / `tr/` — those contain the readable text and images.

How it works
- All page text, the app code and every screenshot are encrypted with one random AES-256-GCM key.
- That key is wrapped once per user ID (PBKDF2-SHA256, 600,000 rounds). The IDs are not stored in the file.
- Screenshots are decrypted only when shown and drawn on <canvas>; no image file, URL or data: string
  exists in the DOM or in the network panel.
- Editors (NEC-Apel, NEC-Polas, NEC-Rony): right-click text or images to edit; Save writes a new
  encrypted file (Chrome/Edge write straight to the chosen file). Guest (NEC-Guest): view only.

Limits (important)
- Login is ID-only, as requested. The IDs are short and guessable, so anyone who guesses one of the
  four IDs can open the file. For real protection, switch to ID + password (change USERS in
  assemble_enc.py so each entry's secret is a long password) and rebuild.
- Anyone already logged in can still take screen captures; no web page can prevent that.
- Edit/view roles are enforced by the app, not by cryptography: all four IDs unwrap the same key.
